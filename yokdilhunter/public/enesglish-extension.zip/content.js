/**
 * YOKDILHUNTER Content Script
 * Shows a translation tooltip or directly saves when the user selects or Alt-clicks
 * an English word/phrase anywhere on the web (including YouTube, Prime Video, Netflix, etc.)
 */

let tooltip = null;
let currentWord = '';
let activeSaveMode = 'ai';
let activeSubtitleMode = 'hover'; // 'hover' | 'dual' | 'off'

// Initialize translation & subtitle mode from storage
if (typeof chrome !== 'undefined' && chrome.storage?.local) {
  chrome.storage.local.get(['translation_mode', 'subtitle_mode'], (data) => {
    if (data?.translation_mode) activeSaveMode = data.translation_mode;
    activeSubtitleMode = data?.subtitle_mode || 'hover';
    handleSubtitleModeChange();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.translation_mode) activeSaveMode = changes.translation_mode.newValue || 'ai';
      if (changes.subtitle_mode) {
        activeSubtitleMode = changes.subtitle_mode.newValue || 'hover';
        handleSubtitleModeChange();
      }
    }
  });
}

// ── Fullscreen & Container Helper ──────────────────────────────────────────
function getAppRoot() {
  return document.fullscreenElement ||
         document.webkitFullscreenElement ||
         document.mozFullScreenElement ||
         document.msFullscreenElement ||
         document.body;
}

// ── Helper: Detect if an element is a Player Control, Menu, or Settings UI ────
function isPlayerControlOrUI(el) {
  if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;

  // 1. Never match our own tooltip, toast, subtitle bar, or nav dock
  if (el.id === 'ydh-tooltip' || el.closest?.('#ydh-tooltip') ||
      el.id === 'ydh-notification-toast' ||
      el.id === 'ydh-sub-translation-bar' ||
      el.closest?.('#ydh-sub-translation-bar') ||
      el.id === 'ydh-nav-controls' ||
      el.closest?.('#ydh-nav-controls')) {
    return false;
  }

  // 2. Never match actual subtitles or caption elements!
  if (el.closest?.(`
    .atvwebplayersdk-captions-overlay,
    .atvwebplayersdk-captions-text,
    .timedTextOutput,
    .timedTextBackground,
    [class*="timedText"],
    [class*="captions-overlay"],
    [class*="captions-text"],
    [class*="caption-window"],
    [class*="caption-visual-line"],
    .player-timedtext,
    .player-timedtext-text-container,
    .ytp-caption-window-bottom,
    .caption-window,
    .caption-visual-line,
    .ytp-caption-segment,
    .dss-subtitle-renderer-line,
    .vjs-text-track-cue,
    .vjs-text-track-display
  `)) {
    return false;
  }

  // 3. Never match video elements or player wrapper roots
  if (
    el.tagName === 'VIDEO' ||
    el.id === 'movie_player' ||
    el.classList?.contains('html5-video-player') ||
    el.classList?.contains('html5-video-container') ||
    el.classList?.contains('html5-main-video') ||
    el.classList?.contains('video-stream') ||
    el.classList?.contains('atvwebplayersdk-player-container') ||
    el.classList?.contains('webPlayerUIContainer') ||
    el.classList?.contains('ytd-player')
  ) {
    return false;
  }

  // 4. Interactive HTML elements & ARIA widgets (Buttons, links, inputs, sliders, menus)
  if (el.closest?.('button, a, input, select, textarea, [role="button"], [role="menu"], [role="menuitem"], [role="menuitemradio"], [role="menuitemcheckbox"], [role="option"], [role="tab"], [role="tablist"], [role="dialog"], [role="slider"], [role="toolbar"], [role="listbox"]')) {
    return true;
  }

  // 5. Specific player controls bar, settings menus, volume sliders
  // (NOTE: Specific selectors used to avoid false positives on #movie_player)
  if (el.closest?.(`
    .ytp-chrome-bottom,
    .ytp-chrome-top,
    .ytp-chrome-controls,
    .ytp-left-controls,
    .ytp-right-controls,
    .ytp-play-button,
    .ytp-volume-panel,
    .ytp-settings-button,
    .ytp-settings-menu,
    .ytp-panel,
    .ytp-popup,
    .ytp-menuitem,
    .ytp-progress-bar-container,
    .ytp-progress-bar,
    .atvwebplayersdk-controls-wrapper,
    .atvwebplayersdk-bottompanel-container,
    .atvwebplayersdk-playpause-button,
    .atvwebplayersdk-fastseek-button,
    [class*="controls-wrapper"],
    [class*="bottompanel-container"],
    [data-uia*="control"],
    [data-uia*="menu"],
    [data-uia*="audio-subtitle"],
    [data-uia*="selector"]
  `)) {
    return true;
  }

  return false;
}

// ── Subtitle Candidate Selectors (Strict Subtitle Text Spans & Containers) ─────
const SUBTITLE_SELECTORS = [
  // YouTube subtitle text segments & spans
  '.ytp-caption-segment',
  '.captions-text span',
  '.captions-text',
  '.caption-visual-line span',
  '.caption-visual-line',
  '.caption-window span',
  // Amazon Prime Video subtitle text containers & spans
  '.atvwebplayersdk-captions-text span',
  '.atvwebplayersdk-captions-text',
  '[class*="captions-text"] span',
  '[class*="captions-text"]',
  '.timedTextBackground span',
  '.timedTextOutput span',
  '.timedTextBackground',
  '.timedTextOutput',
  '.atvwebplayersdk-captions-overlay span',
  '.atvwebplayersdk-captions-overlay .timedTextOutput',
  // Netflix subtitle text containers
  '.player-timedtext-text-container span',
  '.player-timedtext-text-container',
  '.player-timedtext',
  // Disney+, Hulu, HBO Max
  '.dss-subtitle-renderer-line',
  // Video.js text track cues & generic
  '.vjs-text-track-display .vjs-text-track-cue',
  '.vjs-text-track-cue'
];

// Full subtitle cue containers for dual & hover subtitle sentence detection
const SUBTITLE_CONTAINER_SELECTORS = [
  // YouTube
  '.caption-window',
  '.ytp-caption-window-bottom',
  '.ytp-caption-segment',
  '.captions-text',
  // Amazon Prime Video (Target actual cue text boxes)
  '.atvwebplayersdk-captions-text',
  '[class*="captions-text"]',
  '.atvwebplayersdk-captions-overlay .timedTextOutput',
  '.atvwebplayersdk-captions-overlay .timedTextBackground',
  '.timedTextOutput',
  '.timedTextBackground',
  '[class*="timedTextOutput"]',
  '[class*="timedTextBackground"]',
  // Netflix
  '.player-timedtext-text-container',
  // Disney+, Hulu, HBO Max
  '.dss-subtitle-renderer-line',
  // Generic HTML5 / Video.js
  '.vjs-text-track-display .vjs-text-track-cue',
  '.vjs-text-track-cue'
];

// ── Helper: Extract surrounding sentence around range or text ───────────────
function extractSentenceAroundRange(range, word) {
  if (!range) return null;
  try {
    let node = range.commonAncestorContainer;
    while (node && node.nodeType !== Node.ELEMENT_NODE) {
      node = node.parentNode;
    }
    let el = node;
    while (el && el !== document.body && !/^(P|DIV|LI|ARTICLE|SECTION|H[1-6]|BLOCKQUOTE|TD|TH)$/i.test(el.tagName)) {
      if (el.parentNode) el = el.parentNode;
      else break;
    }
    const fullText = (el?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim();
    if (!fullText) return null;
    return extractSentenceFromText(fullText, word);
  } catch {
    return null;
  }
}

function extractSentenceFromText(fullText, word) {
  if (!fullText || !word) return null;
  const idx = fullText.toLowerCase().indexOf(word.toLowerCase());
  if (idx === -1) return null;

  const honorifics = /^(mr|mrs|ms|dr|prof|vs|etc|eg|ie)\.?$/i;
  let start = idx;
  while (start > 0) {
    const prev = fullText[start - 1];
    if (/[.!?\n]/.test(prev)) {
      const beforeDot = fullText.slice(0, start - 1).trim().split(/\s+/).pop();
      if (!honorifics.test(beforeDot)) {
        break;
      }
    }
    start--;
  }

  let end = idx + word.length;
  while (end < fullText.length) {
    const char = fullText[end];
    if (/[.!?\n]/.test(char)) {
      const beforeDot = fullText.slice(idx, end).trim().split(/\s+/).pop();
      if (!honorifics.test(beforeDot)) {
        end++;
        break;
      }
    }
    end++;
  }

  let sentence = fullText.slice(start, end).trim();
  sentence = sentence.replace(/^[^\w"'“‘«]+/, '').trim();
  if (sentence.length >= 10 && sentence.length <= 350) {
    return sentence;
  }
  return null;
}

// ── Helper: Find word and its bounding rect in an element at point (x, y) ──
function findWordInElementAt(el, x, y) {
  if (!el) return null;

  const textNodes = [];
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
  let n;
  while ((n = walker.nextNode())) {
    if (n.nodeValue && n.nodeValue.trim().length > 0) {
      textNodes.push(n);
    }
  }
  if (textNodes.length === 0) return null;

  const wordRegex = /[a-zA-Z0-9'-]+/g;
  const range = document.createRange();

  let closestMatch = null;
  let minDistance = Infinity;

  for (const textNode of textNodes) {
    const text = textNode.nodeValue;
    wordRegex.lastIndex = 0;
    let m;
    while ((m = wordRegex.exec(text)) !== null) {
      const rawWord = m[0];
      const cleanWord = rawWord.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, '');
      if (cleanWord.length < 2 || cleanWord.length > 60 || !/^[a-zA-Z\s\-']+$/.test(cleanWord)) {
        continue;
      }

      try {
        range.setStart(textNode, m.index);
        range.setEnd(textNode, m.index + m[0].length);
        const rect = range.getBoundingClientRect();

        // Direct hit with generous 12px hit padding
        if (x >= rect.left - 12 && x <= rect.right + 12 && y >= rect.top - 12 && y <= rect.bottom + 12) {
          const container = el.closest?.(
            '.timedTextOutput, .timedTextBackground, [class*="timedText"], .atvwebplayersdk-captions-overlay, .player-timedtext, .ytp-caption-window-bottom, .caption-window, [class*="caption"], [class*="subtitle"]'
          ) || el;
          const fullText = (container.innerText || container.textContent || '').replace(/\s+/g, ' ').trim();
          const sentence = extractSentenceAroundRange(range, cleanWord) ||
                           extractSentenceFromText(fullText, cleanWord) ||
                           (fullText.length >= 5 && fullText.length <= 350 ? fullText : null);

          return {
            word: cleanWord,
            sentence,
            rect: {
              top: rect.top,
              left: rect.left,
              width: rect.width,
              height: rect.height
            }
          };
        }

        // Distance check for closest word fallback (e.g. clicked on space or nearby)
        const dx = Math.max(0, rect.left - x, x - rect.right);
        const dy = Math.max(0, rect.top - y, y - rect.bottom);
        const dist = Math.hypot(dx, dy);
        if (dist < minDistance && dist <= 32) {
          minDistance = dist;
          const container = el.closest?.(
            '.timedTextOutput, .timedTextBackground, [class*="timedText"], .atvwebplayersdk-captions-overlay, .player-timedtext, .ytp-caption-window-bottom, .caption-window, [class*="caption"], [class*="subtitle"]'
          ) || el;
          const fullText = (container.innerText || container.textContent || '').replace(/\s+/g, ' ').trim();
          const sentence = extractSentenceAroundRange(range, cleanWord) ||
                           extractSentenceFromText(fullText, cleanWord) ||
                           (fullText.length >= 5 && fullText.length <= 350 ? fullText : null);
          closestMatch = {
            word: cleanWord,
            sentence,
            rect: {
              top: rect.top,
              left: rect.left,
              width: rect.width,
              height: rect.height
            }
          };
        }
      } catch (err) {}
    }
  }

  return closestMatch;
}

// ── Video Helper: Find Active / Overlapping Video ───────────────────────────
function findAssociatedVideo(x, y) {
  // 1. YouTube specific: query player video directly
  const ytPlayer = document.getElementById('movie_player');
  if (ytPlayer) {
    const ytVid = ytPlayer.querySelector('video');
    if (ytVid) return ytVid;
  }
  // 2. Point overlap
  const videos = document.querySelectorAll('video');
  for (const v of videos) {
    const r = v.getBoundingClientRect();
    if (x >= r.left - 20 && x <= r.right + 20 && y >= r.top - 20 && y <= r.bottom + 20) {
      return v;
    }
  }
  for (const v of videos) {
    if (!v.paused) return v;
  }
  return videos[0] || null;
}

function isElementOverVideo(el, video) {
  if (!video || !el) return false;
  const vRect = video.getBoundingClientRect();
  const eRect = el.getBoundingClientRect();
  return (
    eRect.left >= vRect.left - 30 &&
    eRect.right <= vRect.right + 30 &&
    eRect.top >= vRect.top - 30 &&
    eRect.bottom <= vRect.bottom + 30
  );
}

// ── Subtitle-Specific Word Extractor ────────────────────────────────────────
function isElementVisible(el) {
  if (!el || !el.isConnected) return false;
  try {
    const style = window.getComputedStyle(el);
    if (style.display === 'none') return false;
    if (style.visibility === 'hidden' || style.visibility === 'collapse') return false;
    const op = parseFloat(style.opacity);
    if (!isNaN(op) && op < 0.4) return false;

    const rect = el.getBoundingClientRect();
    if (rect.width < 10 || rect.height < 8) return false;
    if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
    if (rect.right < 0 || rect.left > window.innerWidth) return false;

    if (el.offsetParent === null && style.position !== 'fixed' && style.position !== 'sticky') {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function extractSubtitleWordAtPoint(x, y) {
  // If pointer is directly over a button, menu, slider, or player control bar, ignore
  const topEl = document.elementFromPoint ? document.elementFromPoint(x, y) : null;
  if (topEl && isPlayerControlOrUI(topEl)) return null;

  const video = findAssociatedVideo(x, y);

  // Strategy 1: Check known subtitle/caption elements
  const searchRoots = [document];
  try {
    const allCustom = document.querySelectorAll('*');
    for (let i = 0; i < allCustom.length; i++) {
      if (allCustom[i].shadowRoot) searchRoots.push(allCustom[i].shadowRoot);
    }
  } catch {}

  for (const root of searchRoots) {
    try {
      const candidates = root.querySelectorAll(SUBTITLE_SELECTORS.join(','));
      for (const el of candidates) {
        if (!el || isPlayerControlOrUI(el)) continue;
        if (!isElementVisible(el)) continue;
        const rect = el.getBoundingClientRect();
        if (x >= rect.left - 15 && x <= rect.right + 15 && y >= rect.top - 15 && y <= rect.bottom + 15) {
          const match = findWordInElementAt(el, x, y);
          if (match) return { ...match, isSubtitle: true, video };
        }
      }
    } catch {}
  }

  // Strategy 2: Penetrate transparent video overlay shields
  if (document.elementsFromPoint) {
    const elements = document.elementsFromPoint(x, y);
    for (const el of elements) {
      if (!el || el.tagName === 'HTML' || el.tagName === 'BODY' || el.tagName === 'VIDEO') continue;
      if (isPlayerControlOrUI(el)) return null;
      if (el.id === 'ydh-tooltip' || el.closest?.('#ydh-tooltip') || el.id === 'ydh-notification-toast' || el.id === 'ydh-sub-translation-bar') continue;

      const isSubEl = el.matches?.(SUBTITLE_SELECTORS.join(',')) || el.closest?.(SUBTITLE_SELECTORS.join(','));
      if (isSubEl && isElementVisible(el)) {
        const match = findWordInElementAt(el, x, y);
        if (match) return { ...match, isSubtitle: true, video };
      }
    }
  }

  return null;
}

// ── General Word Extractor At Point (x, y) ──────────────────────────────────
function extractWordAtPoint(x, y) {
  // If pointer is directly over a control/button/slider, ignore
  const topEl = document.elementFromPoint ? document.elementFromPoint(x, y) : null;
  if (topEl && isPlayerControlOrUI(topEl)) return null;

  // Try subtitle extraction first
  const subMatch = extractSubtitleWordAtPoint(x, y);
  if (subMatch) return subMatch;

  // Next, elementsFromPoint for any text
  if (document.elementsFromPoint) {
    const elements = document.elementsFromPoint(x, y);
    for (const el of elements) {
      if (!el || el.tagName === 'HTML' || el.tagName === 'BODY' || el.tagName === 'VIDEO') continue;
      if (isPlayerControlOrUI(el)) continue;
      if (el.id === 'ydh-tooltip' || el.closest?.('#ydh-tooltip') || el.id === 'ydh-notification-toast' || el.id === 'ydh-sub-translation-bar') continue;
      const match = findWordInElementAt(el, x, y);
      if (match) return match;
    }
  }

  // Fallback: standard caretRangeFromPoint for normal web pages/articles
  if (document.caretRangeFromPoint) {
    const range = document.caretRangeFromPoint(x, y);
    if (range && range.startContainer.nodeType === Node.TEXT_NODE) {
      if (isPlayerControlOrUI(range.startContainer.parentElement)) return null;
      const text = range.startContainer.nodeValue;
      let start = range.startOffset;
      let end = start;

      while (start > 0 && /[a-zA-Z'-]/.test(text[start - 1])) start--;
      while (end < text.length && /[a-zA-Z'-]/.test(text[end])) end++;

      const extracted = text.slice(start, end).trim();
      const word = extracted.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, '');

      if (word && word.length >= 2 && word.length <= 60 && /^[a-zA-Z\s\-']+$/.test(word)) {
        const sentence = extractSentenceAroundRange(range, word);
        let rect = null;
        try {
          const r = document.createRange();
          r.setStart(range.startContainer, start);
          r.setEnd(range.startContainer, end);
          const b = r.getBoundingClientRect();
          rect = { top: b.top, left: b.left, width: b.width, height: b.height };
        } catch {
          rect = { top: y - 15, left: x - 20, width: 40, height: 30 };
        }
        return { word, sentence, rect };
      }
    }
  }

  return null;
}

// ── Alt-Key Held Feedback (Cursor & Interactivity) ───────────────────────────
window.addEventListener('keydown', (e) => {
  if (e.key === 'Alt' || e.altKey) {
    document.documentElement.classList.add('ydh-alt-held');
  }
}, true);

window.addEventListener('keyup', (e) => {
  if (e.key === 'Alt' || !e.altKey) {
    document.documentElement.classList.remove('ydh-alt-held');
  }
}, true);

window.addEventListener('blur', () => {
  document.documentElement.classList.remove('ydh-alt-held');
});

// ── Sentence Translation Cache & Fetcher ────────────────────────────────────
// ── Sentence Translation Cache & Fetcher (Ultra-Fast 0ms Pre-warmed) ──────
const sentenceCache = new Map();
const pendingTranslations = new Map();

// Purge old potentially corrupted caches from previous broken versions
try {
  sessionStorage.removeItem('ydh_sub_cache');
  sessionStorage.removeItem('ydh_sub_cache_v2');
  sessionStorage.removeItem('ydh_sub_cache_v3');
  sessionStorage.removeItem('ydh_sub_cache_v4');
} catch {}

// Load persistent session cache for instant replay (0ms)
try {
  const saved = sessionStorage.getItem('ydh_sub_cache_v5');
  if (saved) {
    const parsed = JSON.parse(saved);
    for (const [k, v] of Object.entries(parsed)) {
      sentenceCache.set(k, v);
    }
  }
} catch {}

function cacheAndPersist(trimmed, translation) {
  if (!trimmed || !translation) return;
  if (sentenceCache.size > 600) {
    const firstKey = sentenceCache.keys().next().value;
    sentenceCache.delete(firstKey);
  }
  sentenceCache.set(trimmed, translation);
  try {
    const obj = Object.fromEntries(Array.from(sentenceCache.entries()).slice(-300));
    sessionStorage.setItem('ydh_sub_cache_v5', JSON.stringify(obj));
  } catch {}
}

function normalizeSubtitleIdioms(text) {
  if (!text) return '';
  return text
    .replace(/\bup to (my|his|her|your|our|their) asterisk\b/gi, 'up to $1 neck')
    .replace(/\bkiss my asterisk\b/gi, 'kiss my ass')
    .replace(/\bkick (some )?asterisk\b/gi, 'kick $1ass')
    .replace(/\bmy asterisk\b/gi, 'my ass')
    .replace(/\bbad[- ]?asterisk\b/gi, 'badass')
    .replace(/\bpiece of asterisk\b/gi, 'piece of shit');
}

async function fastDirectFetch(trimmed) {
  try {
    const isEnglish = /^[a-zA-Z0-9\s.,!?'"()\-—:;]+$/.test(trimmed);
    const srcLang = isEnglish ? 'en' : 'auto';
    const normalized = normalizeSubtitleIdioms(trimmed);
    const url = `https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=${srcLang}&tl=tr&q=${encodeURIComponent(normalized)}`;
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      if (typeof data === 'string' && data.trim()) return data.trim();
      if (Array.isArray(data)) {
        if (typeof data[0] === 'string' && data[0].trim()) return data[0].trim();
        if (Array.isArray(data[0]) && typeof data[0][0] === 'string' && data[0][0].trim()) return data[0][0].trim();
      }
    }
  } catch {}
  return '';
}

function getSentenceTranslation(sentence) {
  if (!sentence) return Promise.resolve('');
  const trimmed = sentence.replace(/\s+/g, ' ').trim();
  if (sentenceCache.has(trimmed)) {
    return Promise.resolve(sentenceCache.get(trimmed));
  }
  if (pendingTranslations.has(trimmed)) {
    return pendingTranslations.get(trimmed);
  }

  const p = (async () => {
    // 1. Direct fast fetch in content script (~40-80ms blazing fast zero-latency)
    try {
      const direct = await fastDirectFetch(trimmed);
      if (direct && (direct.length >= 2 || trimmed.length <= 2)) {
        cacheAndPersist(trimmed, direct);
        return direct;
      }
    } catch {}

    // 2. Fallback to background service worker via IPC (~100ms)
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action: 'translate_sentence', sentence: trimmed }, (response) => {
          if (chrome.runtime.lastError) {
            resolve('');
            return;
          }
          const translation = (response?.translation || '').trim();
          if (translation && (translation.length >= 2 || trimmed.length <= 2)) {
            cacheAndPersist(trimmed, translation);
            resolve(translation);
          } else {
            resolve('');
          }
        });
      } catch (err) {
        resolve('');
      }
    });
  })().finally(() => {
    pendingTranslations.delete(trimmed);
  });

  pendingTranslations.set(trimmed, p);
  return p;
}

// ── Subtitle Active Cue Detector (Prime Video, YouTube, Netflix, Disney+, HTML5) ──
function findActiveSubtitleCue() {
  const visibleCandidates = [];

  try {
    const elements = document.querySelectorAll(SUBTITLE_CONTAINER_SELECTORS.join(','));
    for (const el of elements) {
      if (!el || isPlayerControlOrUI(el)) continue;
      if (el.id === 'ydh-sub-translation-bar' || el.closest?.('#ydh-sub-translation-bar')) continue;
      if (el.id === 'ydh-tooltip' || el.closest?.('#ydh-tooltip')) continue;

      if (!isElementVisible(el)) continue;

      const rect = el.getBoundingClientRect();
      // Strict geometry sanity check: subtitle cues are never full-screen wrapper overlays!
      if (
        rect.width >= 15 &&
        rect.width <= window.innerWidth * 0.95 &&
        rect.height >= 8 &&
        rect.height <= 180 &&
        rect.bottom > 0 &&
        rect.top < window.innerHeight
      ) {
        const raw = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
        // Must contain at least 2 chars, letters, and not be timecode like "01:23"
        if (raw.length >= 2 && /[a-zA-Z]/.test(raw) && !/^\d+:\d+/.test(raw)) {
          visibleCandidates.push({ el, text: raw, rect });
        }
      }
    }
  } catch {}

  // Discard parent wrapper elements if a more specific child candidate is present
  const nonRedundant = [];
  for (const item of visibleCandidates) {
    const hasChildCandidate = visibleCandidates.some(other => other !== item && item.el.contains(other.el));
    if (!hasChildCandidate) {
      nonRedundant.push(item);
    }
  }

  if (nonRedundant.length > 0) {
    // Sort in visual reading order (top to bottom)
    nonRedundant.sort((a, b) => a.rect.top - b.rect.top);

    // De-duplicate lines cleanly
    const uniqueLines = [];
    for (const item of nonRedundant) {
      const covered = uniqueLines.some(u => u.text === item.text || u.text.includes(item.text));
      if (!covered) {
        const existingIdx = uniqueLines.findIndex(u => item.text.includes(u.text));
        if (existingIdx !== -1) {
          uniqueLines[existingIdx] = item;
        } else {
          uniqueLines.push(item);
        }
      }
    }

    if (uniqueLines.length > 0) {
      const fullText = uniqueLines.map(u => u.text).join(' ');
      let minTop = uniqueLines[0].rect.top;
      let maxBottom = uniqueLines[0].rect.bottom;
      let minLeft = uniqueLines[0].rect.left;
      let maxRight = uniqueLines[0].rect.right;

      for (const u of uniqueLines) {
        minTop = Math.min(minTop, u.rect.top);
        maxBottom = Math.max(maxBottom, u.rect.bottom);
        minLeft = Math.min(minLeft, u.rect.left);
        maxRight = Math.max(maxRight, u.rect.right);
      }

      return {
        el: uniqueLines[0].el,
        text: fullText,
        rect: {
          top: minTop,
          bottom: maxBottom,
          left: minLeft,
          right: maxRight,
          width: maxRight - minLeft,
          height: maxBottom - minTop
        }
      };
    }
  }

  // Fallback 1: check native HTML5 video text tracks
  try {
    const videos = document.querySelectorAll('video');
    for (const v of videos) {
      if (!v.paused && v.textTracks) {
        for (let i = 0; i < v.textTracks.length; i++) {
          const track = v.textTracks[i];
          if (track.mode === 'showing' && track.activeCues && track.activeCues.length > 0) {
            const cue = track.activeCues[0];
            const text = (cue.text || '').replace(/<[^>]+>/g, '').trim();
            if (text.length >= 2 && /[a-zA-Z]/.test(text)) {
              const vRect = v.getBoundingClientRect();
              return {
                el: v,
                text,
                rect: {
                  top: vRect.bottom - 95,
                  bottom: vRect.bottom - 45,
                  left: vRect.left + vRect.width * 0.15,
                  right: vRect.left + vRect.width * 0.85,
                  width: vRect.width * 0.7,
                  height: 50
                }
              };
            }
          }
        }
      }
    }
  } catch {}

  return null;
}

// ── Subtitle Translation Bar Management ─────────────────────────────────────
let subBar = null;
let currentSubSentence = '';
let hoverHideTimeout = null;
let dualSubTimer = null;

function getSubBar() {
  const container = getAppRoot();
  let bar = document.getElementById('ydh-sub-translation-bar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'ydh-sub-translation-bar';
    bar.innerHTML = `<span class="ydh-sub-text"></span>`;
    container.appendChild(bar);
  } else if (bar.parentElement !== container) {
    container.appendChild(bar);
  }
  return bar;
}

// ── Hover Auto-Pause & Resume Engine ─────────────────────────────────────────
let autoPausedByHover = false;
let pausedVideoRef = null;
let wKeyHoverActive = false;

function pauseVideoForSubtitleHover(x, y) {
  if (activeSubtitleMode !== 'hover') return;
  if (autoPausedByHover) return;

  const video = findAssociatedVideo(x, y) || document.querySelector('video');
  if (video && !video.paused) {
    autoPausedByHover = true;
    pausedVideoRef = video;
    try { video.pause(); } catch {}

    const onManualPlay = () => {
      autoPausedByHover = false;
      pausedVideoRef = null;
      wKeyHoverActive = false;
    };
    video.addEventListener('play', onManualPlay, { once: true });

    // YouTube specific
    try {
      const mp = document.getElementById('movie_player');
      if (mp && typeof mp.pauseVideo === 'function') {
        mp.pauseVideo();
      }
    } catch {}
  }
}

function resumeVideoAfterSubtitleHover() {
  if (!autoPausedByHover && !wKeyHoverActive) return;

  // Don't resume if word translation card is open
  if (tooltip && tooltip.classList.contains('ydh-visible')) {
    autoPausedByHover = false;
    pausedVideoRef = null;
    wKeyHoverActive = false;
    return;
  }

  const v = pausedVideoRef || document.querySelector('video');
  autoPausedByHover = false;
  pausedVideoRef = null;
  wKeyHoverActive = false;

  if (v) {
    try {
      const p = v.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {});
      }
    } catch {}
  }

  // YouTube specific
  try {
    const mp = document.getElementById('movie_player');
    if (mp && typeof mp.playVideo === 'function') {
      mp.playVideo();
    }
  } catch {}
}

function hideSubBar() {
  if (subBar) {
    subBar.classList.remove('ydh-sub-visible');
    currentSubSentence = '';
  }
  if (activeSubtitleMode === 'hover' || wKeyHoverActive) {
    resumeVideoAfterSubtitleHover();
  }
}

function toggleHoverSubtitleByKey() {
  closePrimeVideoAudioPanel();
  const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2) || document.querySelector('video');
  if (!video) return;

  // Toggle OFF if already active (hides bar and resumes video playback)
  const isShowingHover = (wKeyHoverActive || autoPausedByHover) && subBar && subBar.classList.contains('ydh-sub-visible');
  if (isShowingHover) {
    wKeyHoverActive = false;
    hideSubBar();
    return;
  }

  // Toggle ON:
  // 1. Locate current active sentence from DOM or preloaded cues
  let activeSub = findActiveSubtitleCue();
  let sentence = activeSub?.text || '';
  let anchorRect = activeSub?.rect || null;

  const now = video.currentTime;
  const cues = getAllSubtitleCues(video);

  if (!sentence && cues && cues.length > 0) {
    const cue = cues.find(c => (c.start - 0.25) <= now && now <= (c.end + 0.35)) ||
                cues.filter(c => c.start <= now && (now - c.end) < 3.5).pop();
    if (cue) {
      sentence = cue.text;
    }
  }

  const vRect = video.getBoundingClientRect();
  if (!anchorRect) {
    anchorRect = {
      top: vRect.bottom - 95,
      bottom: vRect.bottom - 45,
      left: vRect.left + vRect.width * 0.15,
      right: vRect.left + vRect.width * 0.85,
      width: vRect.width * 0.7,
      height: 50
    };
  }

  // Pause the video if currently playing
  if (!video.paused) {
    autoPausedByHover = true;
    pausedVideoRef = video;
    try { video.pause(); } catch {}

    const onManualPlay = () => {
      wKeyHoverActive = false;
      autoPausedByHover = false;
      pausedVideoRef = null;
      if (activeSubtitleMode === 'hover') {
        hideSubBar();
      }
    };
    video.addEventListener('play', onManualPlay, { once: true });

    // YouTube specific
    try {
      const mp = document.getElementById('movie_player');
      if (mp && typeof mp.pauseVideo === 'function') {
        mp.pauseVideo();
      }
    } catch {}
  } else {
    autoPausedByHover = true;
    pausedVideoRef = video;
  }

  wKeyHoverActive = true;

  if (sentence) {
    showSubBar(sentence, anchorRect, false);
  }
}

function updateSubBarPosition(bar, anchorRect, container) {
  if (!bar || !anchorRect) return;

  const isBody = (container === document.body);
  const scrollX = isBody ? (window.scrollX || 0) : 0;
  const scrollY = isBody ? (window.scrollY || 0) : 0;
  const cRect = isBody ? { top: 0, left: 0 } : container.getBoundingClientRect();
  const cScrollTop = isBody ? 0 : container.scrollTop;
  const cScrollLeft = isBody ? 0 : container.scrollLeft;

  // Horizontally centered directly with the English subtitle line
  const left = anchorRect.left - cRect.left + scrollX + cScrollLeft + (anchorRect.width / 2);

  // Vertical placement: place below if room, flip directly above if near bottom edge
  const viewportHeight = window.innerHeight;
  const distFromBottom = viewportHeight - anchorRect.bottom;

  let top;
  let translateY = '0';
  if (distFromBottom < 75) {
    // Too close to viewport bottom: place cleanly above the English subtitle
    top = anchorRect.top - cRect.top + scrollY + cScrollTop - 10;
    translateY = '-100%';
  } else {
    // Standard: place directly below the English subtitle
    top = anchorRect.bottom - cRect.top + scrollY + cScrollTop + 8;
    translateY = '0';
  }

  // Safety clamp: top must NEVER push subtitle above the top of viewport!
  if (translateY === '-100%' && top < 45) {
    top = anchorRect.bottom - cRect.top + scrollY + cScrollTop + 8;
    translateY = '0';
  }

  Object.assign(bar.style, {
    position: 'absolute',
    top: `${Math.round(top)}px`,
    left: `${Math.round(left)}px`,
    transform: `translate(-50%, ${translateY})`,
    zIndex: '2147483646',
  });
}

// ── Subtitle Cues Deduplication & Multi-line Dialogue Combiner ─────────────
function cleanAndMergeCues(rawCues) {
  if (!rawCues || rawCues.length === 0) return [];
  const sorted = [...rawCues].sort((a, b) => a.start - b.start);
  const merged = [];
  for (const cue of sorted) {
    if (!cue || !cue.text) continue;
    const cleanText = cue.text.replace(/\s+/g, ' ').trim();
    if (cleanText.length < 2) continue;
    // Ignore sound-effect-only cues (e.g. [MUSIC], [MÜZİK], ♪, [GÜLÜŞMELER])
    if (/^(\[[^\]]+\]|\([^)]+\)|[♪\s]+)$/.test(cleanText)) continue;
    if (merged.length === 0) {
      merged.push({ start: cue.start, end: cue.end, text: cleanText });
      continue;
    }
    const last = merged[merged.length - 1];

    // Merge only if cues share virtually the same start time (simultaneous multi-line lines in TTML/VTT)
    if (Math.abs(cue.start - last.start) <= 0.35) {
      if (!last.text.includes(cleanText)) {
        last.text = `${last.text} ${cleanText}`.trim();
      }
      last.end = Math.max(last.end, cue.end);
    } else if (cleanText === last.text && Math.abs(cue.start - last.end) <= 0.4) {
      last.end = Math.max(last.end, cue.end);
    } else {
      merged.push({ start: cue.start, end: cue.end, text: cleanText });
    }
  }
  return merged;
}

// ── Lookahead Subtitle Cues & Official Turkish Tracks (0ms Zero-Latency Engine) ──
let preloadedSourceCues = [];
let officialTurkishCues = [];
let lastObservedSubtitleLanguage = 'en';
let lastPreWarmTime = -1;
let lastNavKeyTime = 0;

// Receive intercepted subtitle tracks and navigation keys from interceptor.js (MAIN world)
window.addEventListener('message', (event) => {
  if (event.source !== window || !event.data || event.data.from !== 'ydh_interceptor') return;
  if (event.data.action === 'cues_loaded') {
    const raw = event.data.cues || [];
    const cues = cleanAndMergeCues(raw);
    if (cues && cues.length > 0) {
      if (event.data.lang === 'tr') {
        officialTurkishCues = cues;
      } else {
        preloadedSourceCues = cues;
        const v = document.querySelector('video');
        preWarmUpcomingCues(v?.currentTime || 0);
      }
    }
  } else if (event.data.action === 'nav_key') {
    handleNavKey(event.data.key);
  }
});

// Pre-warms upcoming cues ~60-90 seconds ahead so translations are already in memory (0ms)
function preWarmUpcomingCues(currentTime) {
  const now = currentTime || 0;
  if (Math.abs(now - lastPreWarmTime) < 3) return;
  lastPreWarmTime = now;

  if (preloadedSourceCues && preloadedSourceCues.length > 0) {
    let count = 0;
    for (let i = 0; i < preloadedSourceCues.length; i++) {
      const cue = preloadedSourceCues[i];
      if (cue.start >= now - 5 && cue.start <= now + 75) {
        if (cue.text && cue.text.length >= 2 && !sentenceCache.has(cue.text)) {
          count++;
          getSentenceTranslation(cue.text);
          if (count >= 20) break;
        }
      }
    }
  }
}

// Binds video playback clock and inspects textTracks for native Turkish or source cues
let lastPreWarmedCueText = '';
function preWarmCurrentOnScreenCue() {
  if (activeSubtitleMode !== 'hover' && activeSubtitleMode !== 'dual') return;
  try {
    const cue = findActiveSubtitleCue();
    if (cue && cue.text) {
      const v = document.querySelector('video');
      if (v) trackActiveCue(cue.text, v.currentTime);
      const text = cue.text.replace(/\s+/g, ' ').trim();
      if (text && text !== lastPreWarmedCueText) {
        lastPreWarmedCueText = text;
        if (!sentenceCache.has(text)) {
          getSentenceTranslation(text);
        }
      }
    }
  } catch {}
}

// ── Video / Episode Change Detector (Purges Stale Cues Only on Actual Episode Change) ──
let lastObservedMediaId = '';

function getMediaIdentifier() {
  try {
    const u = new URL(location.href);
    const asin = u.searchParams.get('asin') || u.searchParams.get('titleId');
    if (asin) return asin;
    const detailMatch = u.pathname.match(/\/detail\/([^\/?#]+)/);
    if (detailMatch) return detailMatch[1];
    const netflixMatch = u.pathname.match(/\/watch\/(\d+)/);
    if (netflixMatch) return netflixMatch[1];
    const ytV = u.searchParams.get('v');
    if (ytV) return ytV;
    return u.pathname;
  } catch {
    return location.pathname;
  }
}

function resetAllSubtitleData() {
  observedHistoryCues = [];
  preloadedSourceCues = [];
  officialTurkishCues = [];
  currentActiveCue = null;
  lastFinishedCue = null;
  currentSubSentence = '';
  lastPreWarmTime = -1;
  lastPreWarmedCueText = '';
  hideSubBar();
}

function checkVideoEpisodeChange(video) {
  const currentId = getMediaIdentifier();
  if (currentId && lastObservedMediaId && currentId !== lastObservedMediaId) {
    lastObservedMediaId = currentId;
    resetAllSubtitleData();
  } else if (!lastObservedMediaId && currentId) {
    lastObservedMediaId = currentId;
  }
}

function tryLoadSubtitlesFromPerformanceResources() {
  if (preloadedSourceCues && preloadedSourceCues.length > 0) return;
  try {
    const entries = performance.getEntriesByType('resource');
    for (let i = entries.length - 1; i >= 0; i--) {
      const r = entries[i];
      const u = (r.name || '').toLowerCase();
      if (
        (u.includes('.dfxp') || u.includes('.ttml') || u.includes('.vtt') || u.includes('timedtext') || u.includes('/subtitles') || u.includes('/captions')) &&
        !u.includes('.mp4') && !u.includes('.m4a') && !u.includes('.ts')
      ) {
        fetch(r.name)
          .then(res => res.text())
          .then(text => {
            if (text && text.length > 50) {
              window.postMessage({
                from: 'ydh_content',
                action: 'parse_direct',
                url: r.name,
                content: text
              }, '*');
            }
          })
          .catch(() => {});
        break;
      }
    }
  } catch {}
}

window.addEventListener('popstate', () => {
  checkVideoEpisodeChange();
});

function getOfficialTurkishTranslation(sentence, videoTime) {
  if (!officialTurkishCues || officialTurkishCues.length === 0) return null;
  const now = typeof videoTime === 'number' ? videoTime : (document.querySelector('video')?.currentTime || 0);
  const cleanSentence = (sentence || '').replace(/\s+/g, ' ').trim();

  // 1. Time overlap match with the active English source cue(s)
  if (preloadedSourceCues && preloadedSourceCues.length > 0) {
    const matchingSrc = preloadedSourceCues.filter(c => {
      const isMatch = c.text && (cleanSentence.includes(c.text) || c.text.includes(cleanSentence));
      const isNear = c.start <= (now + 2.5) && c.end >= (now - 2.5);
      return isMatch && isNear;
    });

    if (matchingSrc.length > 0) {
      const srcStart = Math.min(...matchingSrc.map(c => c.start));
      const srcEnd = Math.max(...matchingSrc.map(c => c.end));

      // Find all Turkish cues corresponding to this active dialogue span
      const matchingTr = officialTurkishCues.filter(tr => {
        const overlapStart = Math.max(srcStart, tr.start);
        const overlapEnd = Math.min(srcEnd, tr.end);
        const overlap = Math.max(0, overlapEnd - overlapStart);
        const trDur = Math.max(0.2, tr.end - tr.start);
        const trMid = (tr.start + tr.end) / 2;
        return (overlap / trDur >= 0.35 || overlap >= 0.6) && trMid >= (srcStart - 0.3) && trMid <= (srcEnd + 0.3);
      }).sort((a, b) => a.start - b.start);

      if (matchingTr.length > 0) {
        const seen = new Set();
        const parts = [];
        for (const t of matchingTr) {
          if (!seen.has(t.text)) {
            seen.add(t.text);
            parts.push(t.text);
          }
        }
        return parts.join(' ');
      }
    }
  }

  // 2. Direct time-based match at current playback clock (Fallback when source cues didn't intercept)
  const activeTrCues = officialTurkishCues.filter(c =>
    c.start <= (now + 0.15) && (now - 0.15) <= c.end
  );

  if (activeTrCues.length > 0) {
    activeTrCues.sort((a, b) => a.start - b.start);
    const seen = new Set();
    const parts = [];
    for (const l of activeTrCues) {
      if (!seen.has(l.text)) {
        seen.add(l.text);
        parts.push(l.text);
      }
    }
    return parts.join(' ');
  }

  return null;
}

function syncAndPrewarmVideos() {
  const videos = document.querySelectorAll('video');
  for (const v of videos) {
    checkVideoEpisodeChange(v);

    if (!v._ydhBound) {
      v._ydhBound = true;
      v.addEventListener('timeupdate', () => {
        checkVideoEpisodeChange(v);
        highlightVocabInActiveSubtitles();
        const liveSub = findActiveSubtitleCue();
        if (liveSub?.text) trackActiveCue(liveSub.text, v.currentTime);

        if (activeSubtitleMode === 'dual') {
          scanAndShowDualSubtitle();
          preWarmUpcomingCues(v.currentTime);
        } else if (activeSubtitleMode === 'hover') {
          preWarmUpcomingCues(v.currentTime);
          preWarmCurrentOnScreenCue();
        }
      });
      v.addEventListener('seeked', () => {
        checkVideoEpisodeChange(v);
        highlightVocabInActiveSubtitles();
        const liveSub = findActiveSubtitleCue();
        if (liveSub?.text) trackActiveCue(liveSub.text, v.currentTime);

        if (activeSubtitleMode === 'dual') {
          preWarmUpcomingCues(v.currentTime);
          scanAndShowDualSubtitle();
        } else if (activeSubtitleMode === 'hover') {
          preWarmUpcomingCues(v.currentTime);
          preWarmCurrentOnScreenCue();
        }
      });
    }

    if (v.textTracks) {
      for (let i = 0; i < v.textTracks.length; i++) {
        const track = v.textTracks[i];
        const lang = (track.language || '').toLowerCase();
        const label = (track.label || '').toLowerCase();
        const isTurkish = lang.startsWith('tr') || label.includes('türk') || label.includes('turk');

        // Silently activate Turkish track in background so track.activeCues updates at 60fps
        if (isTurkish && track.mode === 'disabled') {
          track.mode = 'hidden';
        }

        // Read native Turkish track cues if available
        if (isTurkish && track.cues && track.cues.length > 0 && officialTurkishCues.length === 0) {
          const res = [];
          for (let c = 0; c < track.cues.length; c++) {
            const cue = track.cues[c];
            res.push({
              start: cue.startTime,
              end: cue.endTime,
              text: (cue.text || '').replace(/<[^>]+>/g, '').trim()
            });
          }
          if (res.length > 0) {
            officialTurkishCues = cleanAndMergeCues(res);
          }
        }

        // Silently activate source track if disabled to load cues
        if (!isTurkish && track.mode === 'disabled') {
          track.mode = 'hidden';
        }

        // Pre-warm from track.cues if available
        if (!isTurkish && track.cues && track.cues.length > 0) {
          const now = v.currentTime || 0;
          let count = 0;
          for (let c = 0; c < track.cues.length; c++) {
            const cue = track.cues[c];
            if (cue.startTime >= now - 5 && cue.startTime <= now + 75) {
              const raw = (cue.text || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
              if (raw.length >= 2 && !sentenceCache.has(raw)) {
                count++;
                getSentenceTranslation(raw);
                if (count >= 20) break;
              }
            }
          }
        }
      }
    }
  }
}

function showSubBar(sentence, anchorRect, isDual = false) {
  if (!sentence || (activeSubtitleMode === 'off' && !wKeyHoverActive)) {
    hideSubBar();
    return;
  }

  subBar = getSubBar();
  const textEl = subBar.querySelector('.ydh-sub-text');
  const container = getAppRoot();

  const video = document.querySelector('video');
  const officialTr = getOfficialTurkishTranslation(sentence, video?.currentTime);

  // If already displaying this exact sentence, verify position and check if official translation became available
  if (currentSubSentence === sentence && subBar.classList.contains('ydh-sub-visible')) {
    if (!officialTr || textEl.textContent === officialTr) {
      updateSubBarPosition(subBar, anchorRect, container);
      return;
    }
  }

  currentSubSentence = sentence;

  // 1. Prime Video / Platform's Official Turkish Track FIRST (Instant 0ms cinema translation!)
  if (officialTr) {
    textEl.textContent = officialTr;
    textEl.classList.remove('ydh-sub-loading');
    updateSubBarPosition(subBar, anchorRect, container);
    subBar.classList.add('ydh-sub-visible');
    return;
  }

  // 2. Instant Memory Cache (0 ms - previously pre-warmed via Google Translate)
  if (sentenceCache.has(sentence)) {
    textEl.textContent = sentenceCache.get(sentence);
    textEl.classList.remove('ydh-sub-loading');
    updateSubBarPosition(subBar, anchorRect, container);
    subBar.classList.add('ydh-sub-visible');
    return;
  }

  // 3. Immediate zero-latency visual feedback so bar appears instantly
  textEl.textContent = '...';
  textEl.classList.add('ydh-sub-loading');
  updateSubBarPosition(subBar, anchorRect, container);
  subBar.classList.add('ydh-sub-visible');

  // 4. Fallback to Google Translate / Gemini
  getSentenceTranslation(sentence).then((tr) => {
    if (currentSubSentence === sentence && subBar) {
      textEl.textContent = tr || sentence;
      textEl.classList.remove('ydh-sub-loading');
      updateSubBarPosition(subBar, anchorRect, container);
      subBar.classList.add('ydh-sub-visible');
    }
  });
}

// ── User Vocabulary Library Subtitle Highlighting Engine ────────────────────
let userVocabMap = new Map();
let userVocabPhrases = []; // Multi-word phrases sorted by length descending

function buildVocabMap(vocabList) {
  if (!Array.isArray(vocabList)) return;
  userVocabMap.clear();
  userVocabPhrases = [];

  for (const item of vocabList) {
    if (!item || !item.english_word) continue;
    const baseWord = item.english_word.trim().toLowerCase();
    if (!baseWord) continue;

    const entry = {
      word: item.english_word.trim(),
      difficulty: item.difficulty || 'unrated',
      translation: item.turkish_translation || '',
      definition: item.definition || ''
    };

    if (baseWord.includes(' ')) {
      userVocabPhrases.push({ phrase: baseWord, entry });
    } else {
      userVocabMap.set(baseWord, entry);

      // Common English regular inflections
      if (baseWord.endsWith('s') || baseWord.endsWith('x') || baseWord.endsWith('z') || baseWord.endsWith('ch') || baseWord.endsWith('sh')) {
        if (!userVocabMap.has(baseWord + 'es')) userVocabMap.set(baseWord + 'es', entry);
      } else if (baseWord.endsWith('y') && !/[aeiou]y$/i.test(baseWord)) {
        if (!userVocabMap.has(baseWord.slice(0, -1) + 'ies')) userVocabMap.set(baseWord.slice(0, -1) + 'ies', entry);
        if (!userVocabMap.has(baseWord.slice(0, -1) + 'ied')) userVocabMap.set(baseWord.slice(0, -1) + 'ied', entry);
      } else {
        if (!userVocabMap.has(baseWord + 's')) userVocabMap.set(baseWord + 's', entry);
      }

      if (baseWord.endsWith('e')) {
        if (!userVocabMap.has(baseWord + 'd')) userVocabMap.set(baseWord + 'd', entry);
        if (!userVocabMap.has(baseWord.slice(0, -1) + 'ing')) userVocabMap.set(baseWord.slice(0, -1) + 'ing', entry);
      } else {
        if (!userVocabMap.has(baseWord + 'ed')) userVocabMap.set(baseWord + 'ed', entry);
        if (!userVocabMap.has(baseWord + 'ing')) userVocabMap.set(baseWord + 'ing', entry);
        if (baseWord.length >= 3 && /[^aeiou][aeiou][b-df-hj-np-tv-z]$/i.test(baseWord)) {
          const lastChar = baseWord[baseWord.length - 1];
          if (!userVocabMap.has(baseWord + lastChar + 'ing')) userVocabMap.set(baseWord + lastChar + 'ing', entry);
          if (!userVocabMap.has(baseWord + lastChar + 'ed')) userVocabMap.set(baseWord + lastChar + 'ed', entry);
        }
      }
    }
  }

  if (userVocabPhrases.length > 0) {
    userVocabPhrases.sort((a, b) => b.phrase.length - a.phrase.length);
  }
}

function loadUserVocabFromStorage() {
  cleanupLegacyVocabSpans(document);
  if (typeof chrome === 'undefined' || !chrome.storage?.local) return;
  chrome.storage.local.get('ydh_user_vocab', (res) => {
    if (res?.ydh_user_vocab) {
      buildVocabMap(res.ydh_user_vocab);
      highlightVocabInActiveSubtitles();
    }
  });

  try {
    chrome.runtime.sendMessage({ action: 'get_user_vocab' }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response?.vocab) {
        buildVocabMap(response.vocab);
        highlightVocabInActiveSubtitles();
      }
    });
  } catch {}
}

if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.ydh_user_vocab?.newValue) {
      buildVocabMap(changes.ydh_user_vocab.newValue);
      highlightVocabInActiveSubtitles();
    }
  });
}

// ── Safe, Zero-DOM-Mutation Subtitle Vocabulary Highlighting (CSS Custom Highlight API) ──
let highlightMastered = null;
let highlightEasy = null;
let highlightMedium = null;
let highlightHard = null;
let highlightUnrated = null;

function initHighlightRegistry() {
  if (typeof CSS === 'undefined' || !CSS.highlights || typeof Highlight === 'undefined') {
    return false;
  }
  if (!highlightEasy) {
    try {
      highlightMastered = new Highlight();
      highlightEasy = new Highlight();
      highlightMedium = new Highlight();
      highlightHard = new Highlight();
      highlightUnrated = new Highlight();
      CSS.highlights.set('ydh-vocab-mastered', highlightMastered);
      CSS.highlights.set('ydh-vocab-easy', highlightEasy);
      CSS.highlights.set('ydh-vocab-medium', highlightMedium);
      CSS.highlights.set('ydh-vocab-hard', highlightHard);
      CSS.highlights.set('ydh-vocab-unrated', highlightUnrated);
    } catch {
      return false;
    }
  }
  return true;
}

function clearAllVocabHighlights() {
  try {
    highlightMastered?.clear();
    highlightEasy?.clear();
    highlightMedium?.clear();
    highlightHard?.clear();
    highlightUnrated?.clear();
  } catch {}
}

function updateHighlightSet(hlSet, newRanges) {
  if (!hlSet) return;
  try {
    hlSet.clear();
    for (const r of newRanges) {
      hlSet.add(r);
    }
  } catch {}
}

function cleanupLegacyVocabSpans(root = document) {
  try {
    const oldSpans = root.querySelectorAll('.ydh-vocab-word');
    for (const span of oldSpans) {
      const parent = span.parentNode;
      if (parent) {
        const text = span.textContent || '';
        parent.replaceChild(document.createTextNode(text), span);
        parent.normalize();
      }
    }
  } catch {}
}

function findVocabMatchesInText(text) {
  if (!text || text.trim().length < 2) return [];

  const matches = [];

  // 1. Multi-word phrase matching
  if (userVocabPhrases && userVocabPhrases.length > 0) {
    const lower = text.toLowerCase();
    for (const p of userVocabPhrases) {
      let pIdx = lower.indexOf(p.phrase);
      while (pIdx !== -1) {
        const pEnd = pIdx + p.phrase.length;
        const beforeOk = (pIdx === 0 || !/[a-zA-Z0-9]/.test(text[pIdx - 1]));
        const afterOk = (pEnd === text.length || !/[a-zA-Z0-9]/.test(text[pEnd]));
        if (beforeOk && afterOk) {
          const overlaps = matches.some(m => Math.max(m.start, pIdx) < Math.min(m.end, pEnd));
          if (!overlaps) {
            matches.push({
              start: pIdx,
              end: pEnd,
              raw: text.slice(pIdx, pEnd),
              entry: p.entry
            });
          }
        }
        pIdx = lower.indexOf(p.phrase, pEnd);
      }
    }
  }

  // 2. Single word matching
  const wordRegex = /\b([a-zA-Z0-9'-]+)\b/g;
  let m;
  while ((m = wordRegex.exec(text)) !== null) {
    const start = m.index;
    const end = m.index + m[0].length;
    const overlaps = matches.some(item => Math.max(item.start, start) < Math.min(item.end, end));
    if (overlaps) continue;

    const rawWord = m[0];
    const cleanWord = rawWord.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, '').toLowerCase();
    if (cleanWord.length >= 2 && userVocabMap.has(cleanWord)) {
      matches.push({
        start,
        end,
        raw: rawWord,
        entry: userVocabMap.get(cleanWord)
      });
    }
  }

  return matches;
}

function highlightVocabInActiveSubtitles() {
  if (userVocabMap.size === 0 && userVocabPhrases.length === 0) {
    clearAllVocabHighlights();
    return;
  }

  if (!initHighlightRegistry()) return;

  const selector = SUBTITLE_SELECTORS.join(',');
  let elements;
  try {
    elements = document.querySelectorAll(selector);
  } catch {
    clearAllVocabHighlights();
    return;
  }
  if (!elements || elements.length === 0) {
    clearAllVocabHighlights();
    return;
  }

  const masteredRanges = [];
  const easyRanges = [];
  const mediumRanges = [];
  const hardRanges = [];
  const unratedRanges = [];

  for (const el of elements) {
    if (!el || !el.isConnected) continue;
    if (el.id === 'ydh-sub-translation-bar' || el.closest('#ydh-sub-translation-bar')) continue;
    if (el.id === 'ydh-tooltip' || el.closest('#ydh-tooltip')) continue;
    if (el.id === 'ydh-vocab-hover-tip') continue;

    // Fast visibility check: skip invisible elements
    if (!isElementVisible(el)) continue;

    // Leaf subtitle element check: if container has nested subtitle spans, target the leaves
    const childSub = el.querySelector(selector);
    if (childSub) continue;

    const fullText = (el.textContent || '').trim();
    if (fullText.length < 2) continue;

    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
    let textNode;
    while ((textNode = walker.nextNode())) {
      const text = textNode.nodeValue;
      if (!text || text.trim().length < 2) continue;

      const matches = findVocabMatchesInText(text);
      if (!matches || matches.length === 0) continue;

      for (const match of matches) {
        try {
          const r = new Range();
          r.setStart(textNode, match.start);
          r.setEnd(textNode, match.end);
          const diff = match.entry.difficulty || 'unrated';
          if (diff === 'mastered') {
            masteredRanges.push(r);
          } else if (diff === 'easy') {
            easyRanges.push(r);
          } else if (diff === 'medium') {
            mediumRanges.push(r);
          } else if (diff === 'hard') {
            hardRanges.push(r);
          } else {
            unratedRanges.push(r);
          }
        } catch {}
      }
    }
  }

  updateHighlightSet(highlightMastered, masteredRanges);
  updateHighlightSet(highlightEasy, easyRanges);
  updateHighlightSet(highlightMedium, mediumRanges);
  updateHighlightSet(highlightHard, hardRanges);
  updateHighlightSet(highlightUnrated, unratedRanges);
}

// ── Real-time Floating Vocab Hover Tooltip ──────────────────────────────────
let vocabHoverTip = null;
let lastHoveredVocabKey = null;

function getVocabHoverTip() {
  if (!vocabHoverTip || !vocabHoverTip.isConnected) {
    vocabHoverTip = document.createElement('div');
    vocabHoverTip.id = 'ydh-vocab-hover-tip';
    const host = document.fullscreenElement || document.body;
    host?.appendChild(vocabHoverTip);
  } else {
    const host = document.fullscreenElement || document.body;
    if (vocabHoverTip.parentNode !== host) {
      host?.appendChild(vocabHoverTip);
    }
  }
  return vocabHoverTip;
}

function hideVocabHoverTip() {
  if (vocabHoverTip) {
    vocabHoverTip.classList.remove('ydh-visible');
  }
  lastHoveredVocabKey = null;
}

function updateVocabHoverAt(x, y) {
  if (userVocabMap.size === 0 && userVocabPhrases.length === 0) {
    hideVocabHoverTip();
    return;
  }

  if (tooltip && tooltip.classList.contains('ydh-visible')) {
    hideVocabHoverTip();
    return;
  }

  const subWord = extractSubtitleWordAtPoint(x, y);
  if (!subWord || !subWord.word) {
    hideVocabHoverTip();
    return;
  }

  const clean = subWord.word.toLowerCase();
  const entry = userVocabMap.get(clean);
  if (!entry) {
    hideVocabHoverTip();
    return;
  }

  const diff = entry.difficulty || 'unrated';
  const diffLabel = diff === 'mastered' ? '🎓 Ezberlendi' :
                    diff === 'easy' ? '🟢 Kolay' :
                    diff === 'medium' ? '🟡 Orta' :
                    diff === 'hard' ? '🔴 Zor' : '🔵 Yeni';

  const tipText = `${entry.word}: ${entry.translation || 'Çeviri yok'} [${diffLabel}]`;
  const tip = getVocabHoverTip();
  if (lastHoveredVocabKey !== clean) {
    lastHoveredVocabKey = clean;
    tip.textContent = tipText;
  }

  const rect = subWord.rect;
  if (rect) {
    tip.style.left = `${Math.round(rect.left + rect.width / 2)}px`;
    tip.style.top = `${Math.round(Math.max(10, rect.top - 38))}px`;
    tip.classList.add('ydh-visible');
  }
}

// ── Real-time MutationObserver (0ms Instant Subtitle Detection) ─────────────
let subObserver = null;

function setupSubtitleObserver() {
  if (subObserver) return;

  const target = document.querySelector(`
    .atvwebplayersdk-captions-overlay,
    .atvwebplayersdk-captions-text,
    .ytp-caption-window-bottom,
    .caption-window,
    .player-timedtext,
    #movie_player,
    .webPlayerUIContainer
  `) || document.body;

  try {
    subObserver = new MutationObserver(() => {
      highlightVocabInActiveSubtitles();
      if (activeSubtitleMode === 'dual') {
        scanAndShowDualSubtitle();
      } else if (activeSubtitleMode === 'hover') {
        preWarmCurrentOnScreenCue();
      }
    });

    subObserver.observe(target, {
      childList: true,
      subtree: true,
      characterData: true
    });
  } catch {}
}

function teardownSubtitleObserver() {
  if (subObserver) {
    try { subObserver.disconnect(); } catch {}
    subObserver = null;
  }
}

function handleSubtitleModeChange() {
  if (dualSubTimer) {
    clearInterval(dualSubTimer);
    dualSubTimer = null;
  }

  if (activeSubtitleMode === 'dual') {
    resumeVideoAfterSubtitleHover();
    setupSubtitleObserver();
    syncAndPrewarmVideos();
    scanAndShowDualSubtitle();
    dualSubTimer = setInterval(() => {
      scanAndShowDualSubtitle();
      syncAndPrewarmVideos();
    }, 40);
  } else if (activeSubtitleMode === 'hover') {
    setupSubtitleObserver();
    syncAndPrewarmVideos();
    preWarmCurrentOnScreenCue();
    dualSubTimer = setInterval(() => {
      syncAndPrewarmVideos();
      preWarmCurrentOnScreenCue();
    }, 200);
  } else {
    hideSubBar();
    if (userVocabMap.size > 0 || userVocabPhrases.length > 0) {
      setupSubtitleObserver();
    } else {
      teardownSubtitleObserver();
    }
  }
}

function scanAndShowDualSubtitle() {
  if (activeSubtitleMode !== 'dual') {
    if (dualSubTimer) {
      clearInterval(dualSubTimer);
      dualSubTimer = null;
    }
    return;
  }

  // Don't show if word translation tooltip is open
  if (tooltip && tooltip.classList.contains('ydh-visible')) {
    hideSubBar();
    return;
  }

  try {
    const sub = findActiveSubtitleCue();
    if (sub && sub.text) {
      const v = document.querySelector('video');
      if (v) recordObservedCue(sub.text, v.currentTime);
      showSubBar(sub.text, sub.rect, true);
    } else {
      hideSubBar();
    }
  } catch (err) {
    hideSubBar();
  }
}

// ── Hover Mode Mouse Listener ───────────────────────────────────────────────
window.addEventListener('mousemove', (e) => {
  // Update vocabulary hover tooltip on subtitles (works in any subtitle mode!)
  updateVocabHoverAt(e.clientX, e.clientY);

  if (activeSubtitleMode !== 'hover') return;

  // If hovering over player controls, settings menu, or our own tooltip, abort!
  if (isPlayerControlOrUI(e.target) || (tooltip && tooltip.classList.contains('ydh-visible'))) {
    hideSubBar();
    return;
  }

  // 0. Check if hovering over our active subtitle translation bar
  if (subBar && subBar.classList.contains('ydh-sub-visible')) {
    const bRect = subBar.getBoundingClientRect();
    const isOverBar = (
      e.clientX >= bRect.left - 20 &&
      e.clientX <= bRect.right + 20 &&
      e.clientY >= bRect.top - 20 &&
      e.clientY <= bRect.bottom + 20
    );
    if (isOverBar) {
      if (hoverHideTimeout) {
        clearTimeout(hoverHideTimeout);
        hoverHideTimeout = null;
      }
      pauseVideoForSubtitleHover(e.clientX, e.clientY);
      return;
    }
  }

  // 1. Check if hovering over the active subtitle block
  const activeSub = findActiveSubtitleCue();
  if (activeSub) {
    const r = activeSub.rect;
    const isOverSub = (
      e.clientX >= r.left - 25 &&
      e.clientX <= r.right + 25 &&
      e.clientY >= r.top - 25 &&
      e.clientY <= r.bottom + 25
    );

    if (isOverSub) {
      if (hoverHideTimeout) {
        clearTimeout(hoverHideTimeout);
        hoverHideTimeout = null;
      }
      showSubBar(activeSub.text, activeSub.rect, false);
      pauseVideoForSubtitleHover(e.clientX, e.clientY);
      return;
    }
  }

  // 2. Secondary fallback via point-based subtitle extraction
  const subData = extractSubtitleWordAtPoint(e.clientX, e.clientY);
  if (subData?.sentence) {
    if (hoverHideTimeout) {
      clearTimeout(hoverHideTimeout);
      hoverHideTimeout = null;
    }
    const anchorRect = subData.rect || {
      top: e.clientY - 15,
      bottom: e.clientY + 15,
      left: e.clientX - 20,
      right: e.clientX + 20,
      width: 40,
      height: 30
    };
    showSubBar(subData.sentence, anchorRect, false);
    pauseVideoForSubtitleHover(e.clientX, e.clientY);
    return;
  }

  // If moved outside subtitle zone, gracefully hide after 350ms (unless held open by W key)
  if (!hoverHideTimeout && subBar && subBar.classList.contains('ydh-sub-visible')) {
    if (wKeyHoverActive) return;
    hoverHideTimeout = setTimeout(() => {
      hideSubBar();
      hoverHideTimeout = null;
    }, 350);
  }
}, { passive: true });

document.addEventListener('mouseleave', () => {
  hideVocabHoverTip();
  if (wKeyHoverActive) return;
  if (activeSubtitleMode === 'hover' && subBar && subBar.classList.contains('ydh-sub-visible')) {
    hideSubBar();
  }
});

// Fullscreen changes
document.addEventListener('fullscreenchange', () => {
  hideTooltip();
  hideSubBar();
  hideVocabHoverTip();
  handleSubtitleModeChange();
  ensureNavControls();
});
document.addEventListener('webkitfullscreenchange', () => {
  hideTooltip();
  hideSubBar();
  hideVocabHoverTip();
  handleSubtitleModeChange();
  ensureNavControls();
});

// ── Word Card Trigger Helper (Pauses Video & Opens Save Popup) ───────────────
function triggerWordCard(clientX, clientY) {
  autoPausedByHover = false;
  pausedVideoRef = null;
  const data = extractWordAtPoint(clientX, clientY);
  if (!data?.word) return false;

  window.getSelection()?.removeAllRanges();

  // Durdursun: pause video if playing, keep paused if already paused
  const video = data.video || findAssociatedVideo(clientX, clientY);
  if (video) {
    try { video.pause(); } catch {}

    // Lock video in paused state while card is open so it NEVER resumes accidentally
    const keepPaused = () => {
      if (tooltip && tooltip.classList.contains('ydh-visible')) {
        try { video.pause(); } catch {}
      } else {
        video.removeEventListener('play', keepPaused);
      }
    };
    video.addEventListener('play', keepPaused);
  }

  // YouTube specific pause via movie_player API
  try {
    const mp = document.getElementById('movie_player');
    if (mp && typeof mp.pauseVideo === 'function') {
      mp.pauseVideo();
    }
  } catch {}

  const rect = data.rect || { top: clientY - 15, left: clientX - 20, width: 40, height: 30 };
  showTooltip(data.word, rect, data.sentence);
  return true;
}

// ── Scroll Wheel / Middle Click (Button 1): Pause & Open Save Card ──────────
// Prevent all mouse and pointer events for button 1 from reaching video player or activating autoscroll
function blockMiddleEvent(e) {
  if (e.button !== 1) return;
  if (isPlayerControlOrUI(e.target)) return;

  // Over video, player or subtitle: always prevent browser autoscroll
  const isVideoOrSub = e.target.closest?.(`
    video,
    #movie_player,
    .html5-video-player,
    .html5-video-container,
    .caption-window,
    .ytp-caption-segment,
    .captions-text,
    .atvwebplayersdk-captions-overlay,
    .atvwebplayersdk-captions-text,
    .timedTextOutput,
    .player-timedtext,
    #ydh-sub-translation-bar
  `);

  if (isVideoOrSub) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation?.();
  } else {
    const data = extractWordAtPoint(e.clientX, e.clientY);
    if (data?.word) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation?.();
    }
  }
}

window.addEventListener('pointerdown', blockMiddleEvent, true);
window.addEventListener('mousedown', blockMiddleEvent, true);
window.addEventListener('pointerup', blockMiddleEvent, true);
window.addEventListener('mouseup', blockMiddleEvent, true);

// Open card on middle click with debounce
let lastMiddleClickTime = 0;
function handleMiddleClick(e) {
  if (e.button !== 1) return;
  if (tooltip && tooltip.contains(e.target)) return;
  if (isPlayerControlOrUI(e.target)) return;

  const now = Date.now();
  if (now - lastMiddleClickTime < 300) return;

  const handled = triggerWordCard(e.clientX, e.clientY);
  if (handled) {
    lastMiddleClickTime = now;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation?.();
  }
}

window.addEventListener('auxclick', handleMiddleClick, true);
window.addEventListener('mouseup', (e) => {
  if (e.button === 1) handleMiddleClick(e);
}, true);

// ── Direct Click on Highlighted Word / Alt + Left Click ──────────────
window.addEventListener('click', (e) => {
  // If clicked inside our tooltip, let tooltip buttons handle it
  if (tooltip && tooltip.contains(e.target)) return;
  if (isPlayerControlOrUI(e.target)) return;

  // 1. Direct click on a saved vocabulary word in subtitles: pause video & open word details card
  if (e.button === 0 && !e.altKey && !e.shiftKey && !e.ctrlKey) {
    const subWord = extractSubtitleWordAtPoint(e.clientX, e.clientY);
    if (subWord && subWord.word) {
      const clean = subWord.word.toLowerCase();
      if (userVocabMap.has(clean)) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation?.();

        const video = findAssociatedVideo(e.clientX, e.clientY) || document.querySelector('video');
        if (video) {
          try { video.pause(); } catch {}
          const keepPaused = () => {
            if (tooltip && tooltip.classList.contains('ydh-visible')) {
              try { video.pause(); } catch {}
            } else {
              video.removeEventListener('play', keepPaused);
            }
          };
          video.addEventListener('play', keepPaused);
        }
        try {
          const mp = document.getElementById('movie_player');
          if (mp && typeof mp.pauseVideo === 'function') mp.pauseVideo();
        } catch {}

        hideVocabHoverTip();
        showTooltip(subWord.word, subWord.rect, subWord.sentence);
        return;
      }
    }
  }

  // 2. Direct click on a legacy highlighted vocabulary word span (if any): pause video & open word details card
  const vocabSpan = e.target.closest?.('.ydh-vocab-word');
  if (vocabSpan && e.button === 0) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation?.();

    const video = findAssociatedVideo(e.clientX, e.clientY) || document.querySelector('video');
    if (video) {
      try { video.pause(); } catch {}
      const keepPaused = () => {
        if (tooltip && tooltip.classList.contains('ydh-visible')) {
          try { video.pause(); } catch {}
        } else {
          video.removeEventListener('play', keepPaused);
        }
      };
      video.addEventListener('play', keepPaused);
    }
    try {
      const mp = document.getElementById('movie_player');
      if (mp && typeof mp.pauseVideo === 'function') mp.pauseVideo();
    } catch {}

    const word = vocabSpan.dataset.word || vocabSpan.textContent.trim();
    const rect = vocabSpan.getBoundingClientRect();
    const container = vocabSpan.closest(SUBTITLE_CONTAINER_SELECTORS.join(',')) || vocabSpan.parentElement;
    const fullText = (container?.innerText || container?.textContent || '').replace(/\s+/g, ' ').trim();
    const sentence = extractSentenceFromText(fullText, word) || fullText;

    hideVocabHoverTip();
    showTooltip(word, rect, sentence);
    return;
  }

  if (e.altKey && !e.shiftKey && !e.ctrlKey && e.button === 0) {
    const handled = triggerWordCard(e.clientX, e.clientY);
    if (handled) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation?.();
    }
  }
}, true);

// ── Listen for Alt+RightClick (Direct Save) ──────────────────────────────────
window.addEventListener('contextmenu', (e) => {
  if (isPlayerControlOrUI(e.target)) return;
  if (e.altKey && !e.shiftKey && !e.ctrlKey) {
    const data = extractWordAtPoint(e.clientX, e.clientY);
    if (data?.word) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation?.();
      window.getSelection()?.removeAllRanges();

      // Instant feedback toast right on screen
      showToast(`"${data.word}" kaydediliyor... ⏳`);

      chrome.runtime.sendMessage({
        action: 'manual_save',
        word: data.word,
        context_sentence: data.sentence,
        mode: activeSaveMode
      }, (response) => {
        if (chrome.runtime.lastError) {
          showToast(`❌ Hata: ${chrome.runtime.lastError.message}`);
          return;
        }
        if (response?.success) {
          const savedWord = response.result?.english_word || data.word;
          showToast(`"${savedWord}" başarıyla kaydedildi! ✅`);
        } else {
          showToast(response?.error ? `${response.error}` : '❌ Kayıt başarısız oldu');
        }
      });
    }
  }
}, true);

// ── Subtitle-by-Subtitle Navigation Engine (A / D / S keys) ─────────────────
let observedHistoryCues = [];
let navToastTimeout = null;

function trackActiveCue(text, currentTime) {
  if (!text || typeof currentTime !== 'number') return;
  const clean = text.replace(/\s+/g, ' ').trim();
  if (!clean || clean.length < 2) return;
  recordObservedCue(clean, currentTime);
}

function recordObservedCue(text, time) {
  if (!text || typeof time !== 'number') return;
  const clean = text.replace(/\s+/g, ' ').trim();
  if (!clean || clean.length < 2) return;

  const existing = observedHistoryCues.find(c => c.text === clean || Math.abs(c.start - time) < 1.2);
  if (!existing) {
    observedHistoryCues.push({ start: time, end: time + 3.2, text: clean });
    if (observedHistoryCues.length > 500) observedHistoryCues.shift();
    observedHistoryCues.sort((a, b) => a.start - b.start);
  } else {
    existing.end = Math.max(existing.end, time + 0.5);
  }
}

function getAllSubtitleCues(video) {
  // Determine active on-screen subtitle language
  let isTurkishOnScreen = (lastObservedSubtitleLanguage === 'tr');
  const live = findActiveSubtitleCue();
  if (live && live.text) {
    if (/[çğıöşüÇĞİÖŞÜ]/.test(live.text)) {
      isTurkishOnScreen = true;
      lastObservedSubtitleLanguage = 'tr';
    } else if (officialTurkishCues && officialTurkishCues.some(c => Math.abs(c.start - (video?.currentTime || 0)) < 2.5 && (c.text === live.text || live.text.includes(c.text)))) {
      isTurkishOnScreen = true;
      lastObservedSubtitleLanguage = 'tr';
    } else if (preloadedSourceCues && preloadedSourceCues.some(c => Math.abs(c.start - (video?.currentTime || 0)) < 2.5 && (c.text === live.text || live.text.includes(c.text)))) {
      isTurkishOnScreen = false;
      lastObservedSubtitleLanguage = 'en';
    }
  }

  // 1. If Turkish subtitles are actively being watched on screen, prioritize official Turkish cues
  if (isTurkishOnScreen && officialTurkishCues && officialTurkishCues.length > 0) {
    return officialTurkishCues;
  }

  // 2. Intercepted source cues from VTT/TTML/timedtext streams
  if (preloadedSourceCues && preloadedSourceCues.length > 0) {
    return preloadedSourceCues;
  }

  // 3. HTML5 textTracks on the video
  if (video && video.textTracks) {
    for (let i = 0; i < video.textTracks.length; i++) {
      const track = video.textTracks[i];
      if (track.cues && track.cues.length > 0) {
        const res = [];
        for (let c = 0; c < track.cues.length; c++) {
          const cue = track.cues[c];
          res.push({
            start: cue.startTime,
            end: cue.endTime,
            text: (cue.text || '').replace(/<[^>]+>/g, '').trim()
          });
        }
        if (res.length > 0) {
          return cleanAndMergeCues(res);
        }
      }
    }
  }

  // 4. Fallback to official intercepted Turkish cues if source was tagged tr
  if (officialTurkishCues && officialTurkishCues.length > 0) {
    return officialTurkishCues;
  }

  // 5. Observed DOM history cues
  if (observedHistoryCues && observedHistoryCues.length > 0) {
    return cleanAndMergeCues(observedHistoryCues);
  }
  return [];
}

function seekVideoToTime(video, targetSeconds) {
  if (!video) return;
  const clamped = Math.max(0, Math.min(video.duration || 999999, targetSeconds));

  // 1. YouTube specific seek API
  try {
    const mp = document.getElementById('movie_player');
    if (mp && typeof mp.seekTo === 'function') {
      mp.seekTo(clamped, true);
    }
  } catch {}

  // 2. Standard HTML5 seek
  try {
    video.currentTime = clamped;
  } catch {}
}

function showNavToast(message) {
  if (!message) return;
  const container = getAppRoot();
  let toast = document.getElementById('ydh-sub-nav-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'ydh-sub-nav-toast';
    container.appendChild(toast);
  } else if (toast.parentElement !== container) {
    container.appendChild(toast);
  }

  const cleanMsg = message.length > 60 ? (message.slice(0, 57) + '...') : message;
  toast.textContent = cleanMsg;
  toast.classList.add('ydh-nav-visible');

  if (navToastTimeout) clearTimeout(navToastTimeout);
  navToastTimeout = setTimeout(() => {
    toast?.classList.remove('ydh-nav-visible');
    navToastTimeout = null;
  }, 1200);
}

function closePrimeVideoAudioPanel() {
  try {
    const dialogs = document.querySelectorAll(`
      .atvwebplayersdk-subtitles-overlay,
      [class*="subtitles-overlay"],
      [data-testid*="subtitles"],
      [data-testid*="audio-subtitles"]
    `);
    dialogs.forEach(dialog => {
      const closeBtn = dialog.querySelector('button[aria-label*="close" i], button[aria-label*="kapat" i], .close-button');
      if (closeBtn) closeBtn.click();
    });
  } catch {}
}

function isInputActive(target) {
  const activeEl = document.activeElement;
  const t = target || activeEl;
  if (!t) return false;
  const tag = (t.tagName || '').toUpperCase();
  const activeTag = (activeEl?.tagName || '').toUpperCase();
  if (tag === 'INPUT' || tag === 'TEXTAREA' || t.isContentEditable) return true;
  if (activeTag === 'INPUT' || activeTag === 'TEXTAREA' || activeEl?.isContentEditable) return true;
  if (t.closest?.('input, textarea, [contenteditable="true"], [role="textbox"], [role="searchbox"], #ydh-tooltip')) return true;
  if (activeEl?.closest?.('input, textarea, [contenteditable="true"], [role="textbox"], [role="searchbox"], #ydh-tooltip')) return true;
  return false;
}

function handleNavKey(key) {
  if (!key) return;
  if (isInputActive(document.activeElement)) return;
  const k = key.toLowerCase();
  if (k !== 'a' && k !== 'd' && k !== 's' && k !== 'w') return;

  const now = Date.now();
  if (now - lastNavKeyTime < 180) return;
  lastNavKeyTime = now;

  if (k === 'w') {
    toggleHoverSubtitleByKey();
    return;
  }

  // Reset subtitle state before seek so stale cached sentence doesn't linger
  currentSubSentence = '';
  wKeyHoverActive = false;
  if (subBar) {
    subBar.classList.remove('ydh-sub-visible');
  }

  if (k === 'a') {
    jumpToPreviousSubtitle();
  } else if (k === 'd') {
    jumpToNextSubtitle();
  } else if (k === 's') {
    repeatCurrentSubtitle();
  }
}

function jumpToPreviousSubtitle() {
  closePrimeVideoAudioPanel();
  const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2);
  if (!video) return;

  checkVideoEpisodeChange(video);
  const now = video.currentTime;
  let cues = getAllSubtitleCues(video);
  if (!cues || cues.length === 0) {
    tryLoadSubtitlesFromPerformanceResources();
    cues = getAllSubtitleCues(video);
  }

  if (cues && cues.length > 0) {
    // 1. Check if currently inside a cue
    const currentCueIndex = cues.findIndex(c => (c.start - 0.2) <= now && now <= (c.end + 0.2));

    if (currentCueIndex > 0) {
      // Step strictly to previous cue
      const prevCue = cues[currentCueIndex - 1];
      seekVideoToTime(video, prevCue.start);
      showNavToast(`⏮ ${prevCue.text}`);
      return;
    } else if (currentCueIndex === 0) {
      // Very first cue of the video
      seekVideoToTime(video, Math.max(0, cues[0].start));
      showNavToast(`⏮ ${cues[0].text}`);
      return;
    }

    // 2. Between cues: find the immediate last cue that started before now
    const pastCues = cues.filter(c => c.start < (now - 0.2));
    if (pastCues.length > 0) {
      const prevCue = pastCues[pastCues.length - 1];
      seekVideoToTime(video, prevCue.start);
      showNavToast(`⏮ ${prevCue.text}`);
      return;
    }
  }

  // Fallback if no cues: rewind 3.0s
  seekVideoToTime(video, Math.max(0, now - 3.0));
  showNavToast(`⏮ -3s`);
}

function jumpToNextSubtitle() {
  closePrimeVideoAudioPanel();
  const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2);
  if (!video) return;

  checkVideoEpisodeChange(video);
  const now = video.currentTime;
  let cues = getAllSubtitleCues(video);
  if (!cues || cues.length === 0) {
    tryLoadSubtitlesFromPerformanceResources();
    cues = getAllSubtitleCues(video);
  }

  if (cues && cues.length > 0) {
    // Find next cue starting strictly after now + 0.25s
    const nextCue = cues.find(c => c.start > (now + 0.25));
    if (nextCue) {
      seekVideoToTime(video, nextCue.start);
      showNavToast(`⏭ ${nextCue.text}`);
      return;
    } else {
      showNavToast('⏭ Son altyazı');
      return;
    }
  }

  // Fallback: jump 3.0s forward
  seekVideoToTime(video, now + 3.0);
  showNavToast(`⏭ +3s`);
}

function repeatCurrentSubtitle() {
  closePrimeVideoAudioPanel();
  const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2);
  if (!video) return;

  checkVideoEpisodeChange(video);
  const now = video.currentTime;
  let cues = getAllSubtitleCues(video);
  if (!cues || cues.length === 0) {
    tryLoadSubtitlesFromPerformanceResources();
    cues = getAllSubtitleCues(video);
  }

  // 1. Search official/preloaded cues FIRST (exact cue.start)
  if (cues && cues.length > 0) {
    const currentCue = cues.find(c => (c.start - 0.25) <= now && now <= (c.end + 0.35));
    if (currentCue) {
      seekVideoToTime(video, currentCue.start);
      showNavToast(`🔁 ${currentCue.text}`);
      return;
    }

    // Cue that ended within the last 3.5 seconds
    const recentCues = cues.filter(c => c.start <= now && (now - c.end) < 3.5);
    if (recentCues.length > 0) {
      const target = recentCues[recentCues.length - 1];
      seekVideoToTime(video, target.start);
      showNavToast(`🔁 ${target.text}`);
      return;
    }

    // Fallback: most recent cue
    const pastCues = cues.filter(c => c.start <= now);
    if (pastCues.length > 0) {
      const target = pastCues[pastCues.length - 1];
      seekVideoToTime(video, target.start);
      showNavToast(`🔁 ${target.text}`);
      return;
    }
  }

  // 2. Active DOM subtitle fallback
  const activeDomCue = findActiveSubtitleCue();
  if (activeDomCue && activeDomCue.text) {
    showNavToast(`🔁 ${activeDomCue.text}`);
    return;
  }

  // 3. Fallback if no cues: rewind 3.0 seconds
  seekVideoToTime(video, Math.max(0, now - 3.0));
  showNavToast(`🔁 -3s`);
}

// ── Floating On-Screen Navigation Controls (Left Screen Pill Dock) ───────────
function ensureNavControls() {
  const container = getAppRoot();
  let controls = document.getElementById('ydh-nav-controls');
  if (!controls) {
    controls = document.createElement('div');
    controls.id = 'ydh-nav-controls';
    controls.innerHTML = `
      <button type="button" class="ydh-nav-btn ydh-nav-settings" title="Altyazı Modu ve Ayarlar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="3"></circle>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
        </svg>
      </button>
      <div class="ydh-nav-divider"></div>
      <button type="button" class="ydh-nav-btn ydh-nav-prev" title="Önceki Altyazı (A)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="11 19 2 12 11 5 11 19"></polygon>
          <polygon points="22 19 13 12 22 5 22 19"></polygon>
        </svg>
      </button>
      <button type="button" class="ydh-nav-btn ydh-nav-repeat" title="Altyazıyı Tekrar Et (S)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M1 4v6h6"></path>
          <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
        </svg>
      </button>
      <button type="button" class="ydh-nav-btn ydh-nav-next" title="Sonraki Altyazı (D)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="13 19 22 12 13 5 13 19"></polygon>
          <polygon points="2 19 11 12 2 5 2 19"></polygon>
        </svg>
      </button>

      <div id="ydh-nav-menu">
        <div class="ydh-menu-header">Altyazı Modu</div>
        <button type="button" class="ydh-menu-item" data-mode="hover">
          <div class="ydh-item-title-row">
            <span class="ydh-item-title">Hover Modu (W)</span>
            <svg class="ydh-item-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
          </div>
          <span class="ydh-item-desc">Fare üstüne gelince veya W ile çevirir</span>
        </button>
        <button type="button" class="ydh-menu-item" data-mode="dual">
          <div class="ydh-item-title-row">
            <span class="ydh-item-title">Çift Altyazı</span>
            <svg class="ydh-item-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
          </div>
          <span class="ydh-item-desc">Her iki dili sürekli aynı anda gösterir</span>
        </button>
        <button type="button" class="ydh-menu-item" data-mode="off">
          <div class="ydh-item-title-row">
            <span class="ydh-item-title">Kapalı</span>
            <svg class="ydh-item-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
          </div>
          <span class="ydh-item-desc">Çeviri çubuğunu devre dışı bırakır</span>
        </button>
      </div>
    `;

    const settingsBtn = controls.querySelector('.ydh-nav-settings');
    const menu = controls.querySelector('#ydh-nav-menu');

    function updateNavMenuState() {
      const items = controls.querySelectorAll('.ydh-menu-item');
      items.forEach(it => {
        const mode = it.getAttribute('data-mode');
        if (mode === activeSubtitleMode) {
          it.classList.add('ydh-item-active');
        } else {
          it.classList.remove('ydh-item-active');
        }
      });
    }

    settingsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      updateNavMenuState();
      menu.classList.toggle('ydh-menu-open');
      settingsBtn.classList.toggle('ydh-active', menu.classList.contains('ydh-menu-open'));
    });

    const items = controls.querySelectorAll('.ydh-menu-item');
    items.forEach(it => {
      it.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const mode = it.getAttribute('data-mode');
        if (mode) {
          activeSubtitleMode = mode;
          try {
            if (typeof chrome !== 'undefined' && chrome.storage?.local) {
              chrome.storage.local.set({ subtitle_mode: mode });
            }
          } catch {}
          handleSubtitleModeChange();
          updateNavMenuState();
          menu.classList.remove('ydh-menu-open');
          settingsBtn.classList.remove('ydh-active');
          const labels = {
            hover: 'Hover Modu (W)',
            dual: 'Çift Altyazı',
            off: 'Kapalı'
          };
          showNavToast(`Mod: ${labels[mode] || mode}`);
        }
      });
    });

    controls.querySelector('.ydh-nav-prev').addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleNavKey('a');
    });
    controls.querySelector('.ydh-nav-repeat').addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleNavKey('s');
    });
    controls.querySelector('.ydh-nav-next').addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleNavKey('d');
    });

    controls.addEventListener('mousedown', (e) => e.stopPropagation());
    controls.addEventListener('pointerdown', (e) => e.stopPropagation());
    controls.addEventListener('click', (e) => e.stopPropagation());

    document.addEventListener('click', (e) => {
      if (controls && !controls.contains(e.target)) {
        menu?.classList.remove('ydh-menu-open');
        settingsBtn?.classList.remove('ydh-active');
      }
    });

    container.appendChild(controls);
  } else if (controls.parentElement !== container) {
    container.appendChild(controls);
  }

  const hasVideo = document.querySelector('video') || document.querySelector('.html5-video-player');
  controls.style.display = hasVideo ? 'flex' : 'none';
}

// Global Keyboard Listener for W / A / D / S subtitle navigation & hover toggle (fallback / direct)
window.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  if (isInputActive(e.target || document.activeElement)) return;

  let key = (e.key || '').toLowerCase();
  if (!key) {
    if (e.code === 'KeyA') key = 'a';
    else if (e.code === 'KeyD') key = 'd';
    else if (e.code === 'KeyS') key = 's';
    else if (e.code === 'KeyW') key = 'w';
  }

  if (key === 'a' || key === 'd' || key === 's' || key === 'w') {
    const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2);
    if (!video) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation?.();

    handleNavKey(key);
  }
}, true);

// Swallow keyup and keypress so Prime Video's native listeners never see 'A' or 'W'
const swallowNavRelease = (e) => {
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  if (isInputActive(e.target || document.activeElement)) return;

  let key = (e.key || '').toLowerCase();
  if (!key) {
    if (e.code === 'KeyA') key = 'a';
    else if (e.code === 'KeyD') key = 'd';
    else if (e.code === 'KeyS') key = 's';
    else if (e.code === 'KeyW') key = 'w';
  }

  if (key === 'a' || key === 'd' || key === 's' || key === 'w') {
    const video = findAssociatedVideo(window.innerWidth / 2, window.innerHeight / 2);
    if (video) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation?.();
      closePrimeVideoAudioPanel();
    }
  }
};

window.addEventListener('keyup', swallowNavRelease, true);
window.addEventListener('keypress', swallowNavRelease, true);

// ── Listen for text selection (Mouseup) ─────────────────────────────────────
document.addEventListener('mouseup', (e) => {
  if (tooltip && tooltip.contains(e.target)) return;

  setTimeout(() => {
    const selection = window.getSelection();
    const text = selection?.toString()?.trim();

    if (!text || text === currentWord) return;

    // Only 1–4 English words
    const words = text.split(/\s+/);
    if (words.length < 1 || words.length > 4) { hideTooltip(); return; }
    if (text.length > 60) { hideTooltip(); return; }
    if (!/^[a-zA-Z\s\-']+$/.test(text)) { hideTooltip(); return; }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const sentence = extractSentenceAroundRange(range, text);
    showTooltip(text, rect, sentence);
  }, 120);
});

// Hide when clicking outside tooltip
document.addEventListener('mousedown', (e) => {
  if (tooltip && !tooltip.contains(e.target)) hideTooltip();
});

// Hide on scroll
document.addEventListener('scroll', hideTooltip, { passive: true });

// ── Show tooltip ───────────────────────────────────────────────────────────
function showTooltip(word, rect, contextSentence = null) {
  autoPausedByHover = false;
  pausedVideoRef = null;
  hideTooltip();
  hideSubBar();
  injectStyles();
  currentWord = word;

  const cleanWord = word.trim().toLowerCase();
  const knownEntry = userVocabMap.get(cleanWord) || userVocabMap.get(cleanWord.replace(/s$|es$|ed$|ing$/i, ''));
  const isKnown = !!knownEntry;

  const container = getAppRoot();

  tooltip = document.createElement('div');
  tooltip.id = 'ydh-tooltip';

  if (isKnown) {
    const diff = knownEntry.difficulty || 'unrated';
    const diffLabel = diff === 'mastered' ? '🎓 Ezberlendi' :
                      diff === 'easy' ? '🟢 Kolay' :
                      diff === 'medium' ? '🟡 Orta' :
                      diff === 'hard' ? '🔴 Zor' : '🔵 Yeni';

    tooltip.innerHTML = `
      <div class="ydh-word-header">
        <div class="ydh-word">${escHtml(knownEntry.word || word)}</div>
        <span class="ydh-diff-badge ydh-badge-${diff}">${diffLabel}</span>
      </div>
      <div class="ydh-translation">${escHtml(knownEntry.translation || 'Kütüphanende kayıtlı')}</div>
      ${knownEntry.definition ? `<div class="ydh-definition" style="font-size:12px;color:#94a3b8;margin-bottom:8px;">${escHtml(knownEntry.definition)}</div>` : ''}
      
      <div class="ydh-diff-quick-bar" style="margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.08);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-size:11px;color:#94a3b8;font-weight:600;">Zorluk Derecesini Değiştir:</span>
          <span class="ydh-diff-feedback" style="font-size:10px;font-weight:bold;color:#4ade80;"></span>
        </div>
        <div class="ydh-diff-buttons" style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;">
          <button type="button" class="ydh-diff-rate-btn ${diff==='hard'?'active':''}" data-rate="hard" title="Zor (1 gün)">🔴 Zor</button>
          <button type="button" class="ydh-diff-rate-btn ${diff==='medium'?'active':''}" data-rate="medium" title="Orta (3 gün)">🟡 Orta</button>
          <button type="button" class="ydh-diff-rate-btn ${diff==='easy'?'active':''}" data-rate="easy" title="Kolay (10 gün)">🟢 Kolay</button>
          <button type="button" class="ydh-diff-rate-btn ${diff==='mastered'?'active':''}" data-rate="mastered" title="Ezberledim (Çok Kolay)">🎓 Ezberledim</button>
        </div>
      </div>
    `;

    // Hook up quick rate buttons
    const rateBtns = tooltip.querySelectorAll('.ydh-diff-rate-btn');
    const badgeEl = tooltip.querySelector('.ydh-diff-badge');
    const feedbackEl = tooltip.querySelector('.ydh-diff-feedback');

    rateBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const newRate = btn.getAttribute('data-rate');
        if (!newRate) return;

        rateBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if (feedbackEl) {
          feedbackEl.textContent = 'Kaydediliyor...';
          feedbackEl.style.color = '#38bdf8';
        }

        chrome.runtime.sendMessage({
          action: 'update_word_difficulty',
          word: knownEntry.word || word,
          difficulty: newRate
        }, (res) => {
          if (res && res.success) {
            knownEntry.difficulty = newRate;
            userVocabMap.set(cleanWord, knownEntry);
            const newLabel = newRate === 'mastered' ? '🎓 Ezberlendi' :
                             newRate === 'easy' ? '🟢 Kolay' :
                             newRate === 'medium' ? '🟡 Orta' :
                             newRate === 'hard' ? '🔴 Zor' : '🔵 Yeni';
            if (badgeEl) {
              badgeEl.className = `ydh-diff-badge ydh-badge-${newRate}`;
              badgeEl.textContent = newLabel;
            }
            if (feedbackEl) {
              feedbackEl.textContent = '✓ Kaydedildi';
              feedbackEl.style.color = '#4ade80';
              setTimeout(() => { if (feedbackEl) feedbackEl.textContent = ''; }, 2000);
            }
            highlightVocabInActiveSubtitles();
          } else {
            if (feedbackEl) {
              feedbackEl.textContent = '✗ ' + (res?.error || 'Hata');
              feedbackEl.style.color = '#f87171';
            }
          }
        });
      });
    });
  } else {
    tooltip.innerHTML = `
      <div class="ydh-word">${escHtml(word)}</div>
      <div class="ydh-translation ydh-loading">çeviriliyor...</div>
      <div class="ydh-mode-container">
        <span class="ydh-mode-label">Kayıt:</span>
        <div class="ydh-mode-pills">
          <button type="button" class="ydh-pill ${activeSaveMode === 'ai' ? 'ydh-pill-active' : ''}" data-mode="ai">✨ AI (4 Anlam)</button>
          <button type="button" class="ydh-pill ${activeSaveMode === 'classic' ? 'ydh-pill-active' : ''}" data-mode="classic">⚡ Klasik</button>
        </div>
      </div>
      <button class="ydh-save-btn" disabled>💾 Kaydet</button>
    `;

    // Handle mode pill switching
    const pills = tooltip.querySelectorAll('.ydh-pill');
    pills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.stopPropagation();
        const mode = pill.getAttribute('data-mode');
        activeSaveMode = mode;
        pills.forEach(p => p.classList.remove('ydh-pill-active'));
        pill.classList.add('ydh-pill-active');
        if (typeof chrome !== 'undefined' && chrome.storage?.local) {
          chrome.storage.local.set({ translation_mode: mode });
        }
      });
    });
  }

  // Calculate coordinates relative to container (handles fullscreen and standard body)
  let top, left;
  if (container === document.body) {
    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;
    top = rect.top + scrollY - 10;
    left = rect.left + scrollX + rect.width / 2;
  } else {
    const cRect = container.getBoundingClientRect();
    top = rect.top - cRect.top + container.scrollTop - 10;
    left = rect.left - cRect.left + container.scrollLeft + rect.width / 2;
  }

  // Prevent overflowing above screen
  const isNearTop = rect.top < 100;
  if (isNearTop) {
    const bottomTop = top + (rect.height || 20) + 20;
    Object.assign(tooltip.style, {
      position: 'absolute',
      top: `${bottomTop}px`,
      left: `${left}px`,
      transform: 'translate(-50%, 0)',
      zIndex: '2147483647',
    });
    tooltip.classList.add('ydh-tooltip-bottom');
  } else {
    Object.assign(tooltip.style, {
      position: 'absolute',
      top: `${top}px`,
      left: `${left}px`,
      transform: 'translate(-50%, -100%)',
      zIndex: '2147483647',
    });
    tooltip.classList.remove('ydh-tooltip-bottom');
  }

  container.appendChild(tooltip);

  // Animate in
  requestAnimationFrame(() => tooltip?.classList.add('ydh-visible'));

  if (!isKnown) {
    // Fetch fast translation from background
    chrome.runtime.sendMessage({ action: 'translate', word }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Translation error:', chrome.runtime.lastError);
        if (!tooltip) return;
        const transEl = tooltip.querySelector('.ydh-translation');
        if (transEl) {
          transEl.textContent = 'Hata: ' + chrome.runtime.lastError.message;
          transEl.classList.remove('ydh-loading');
          transEl.classList.add('ydh-error');
        }
        return;
      }

      if (!tooltip) return;
      const transEl = tooltip.querySelector('.ydh-translation');
      const saveBtn = tooltip.querySelector('.ydh-save-btn');

      if (response?.translation) {
        if (transEl) {
          transEl.textContent = response.translation;
          transEl.classList.remove('ydh-loading');
        }
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.addEventListener('click', () => saveWord(word, saveBtn, contextSentence, activeSaveMode));
        }
      } else {
        if (transEl) {
          transEl.textContent = response?.error || 'çeviri bulunamadı';
          transEl.classList.remove('ydh-loading');
          transEl.classList.add('ydh-error');
        }
      }
    });
  }
}

// ── Bottom-Right Toast Notification ─────────────────────────────────────────
let toastTimer = null;
function showToast(message) {
  const container = getAppRoot();
  let toast = container.querySelector('#ydh-notification-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'ydh-notification-toast';
    container.appendChild(toast);
  }

  const isSuccess = message.includes('✅');
  const isError = message.includes('❌') || message.includes('zaten') || message.includes('Lütfen') || message.includes('Hata');

  let borderColor = 'rgba(99, 102, 241, 0.5)';
  if (isSuccess) borderColor = 'rgba(74, 222, 128, 0.6)';
  if (isError) borderColor = 'rgba(248, 113, 113, 0.6)';

  toast.textContent = message;
  Object.assign(toast.style, {
    position: 'fixed',
    bottom: '24px',
    right: '24px',
    backgroundColor: '#0F172A',
    border: `1px solid ${borderColor}`,
    color: '#F8FAFC',
    padding: '12px 20px',
    borderRadius: '10px',
    fontFamily: "'Segoe UI', system-ui, -apple-system, sans-serif",
    fontSize: '14px',
    fontWeight: '500',
    boxShadow: '0 10px 25px -3px rgba(0, 0, 0, 0.6), 0 0 15px rgba(99, 102, 241, 0.2)',
    zIndex: '2147483647',
    transition: 'all 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
    opacity: '0',
    transform: 'translateY(12px)',
    pointerEvents: 'none'
  });

  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  });

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(12px)';
    setTimeout(() => {
      toast?.remove();
    }, 300);
  }, 3500);
}

// Listen for toast messages from background (Ctrl+Shift+S or context menu)
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'show_toast') {
    showToast(message.text);
  }
});

// ── Save word ──────────────────────────────────────────────────────────────
function saveWord(word, btn, contextSentence = null, mode = 'ai') {
  hideTooltip();
  showToast(`"${word}" kaydediliyor... ⏳`);

  chrome.runtime.sendMessage({
    action: 'manual_save',
    word,
    context_sentence: contextSentence,
    mode: mode
  }, (response) => {
    if (chrome.runtime.lastError) {
      showToast(`❌ Hata: ${chrome.runtime.lastError.message}`);
      return;
    }
    if (response?.success) {
      const savedWord = response.result?.english_word || word;
      showToast(`"${savedWord}" başarıyla kaydedildi! ✅`);
    } else {
      showToast(response?.error ? `${response.error}` : '❌ Kayıt başarısız oldu');
    }
  });
}

// ── Hide tooltip ───────────────────────────────────────────────────────────
function hideTooltip() {
  if (!tooltip) return;
  tooltip.classList.remove('ydh-visible');
  setTimeout(() => {
    tooltip?.remove();
    tooltip = null;
    currentWord = '';
  }, 180);
}

// ── Inject styles ──────────────────────────────────────────────────────────
let stylesInjected = false;
function injectStyles() {
  if (stylesInjected && document.getElementById('ydh-injected-styles')) return;
  stylesInjected = true;

  const style = document.createElement('style');
  style.id = 'ydh-injected-styles';
  style.textContent = `
    #ydh-tooltip {
      background: #0f172a;
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 12px;
      padding: 10px 14px;
      min-width: 160px;
      max-width: 280px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,102,241,0.1);
      font-family: 'Segoe UI', system-ui, sans-serif;
      color: #f8fafc;
      opacity: 0;
      transform: translate(-50%, -100%) translateY(-4px);
      transition: opacity 0.18s ease, transform 0.18s ease;
      pointer-events: auto;
      user-select: none;
    }
    #ydh-tooltip.ydh-visible {
      opacity: 1;
      transform: translate(-50%, -100%) translateY(-8px);
    }
    #ydh-tooltip.ydh-tooltip-bottom.ydh-visible {
      transform: translate(-50%, 0) translateY(8px);
    }
    #ydh-tooltip::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 50%;
      transform: translateX(-50%) rotate(45deg);
      width: 10px;
      height: 10px;
      background: #0f172a;
      border-right: 1px solid rgba(99,102,241,0.4);
      border-bottom: 1px solid rgba(99,102,241,0.4);
    }
    #ydh-tooltip.ydh-tooltip-bottom::after {
      bottom: auto;
      top: -5px;
      border-right: none;
      border-bottom: none;
      border-left: 1px solid rgba(99,102,241,0.4);
      border-top: 1px solid rgba(99,102,241,0.4);
    }
    .ydh-word {
      font-size: 13px;
      font-weight: 700;
      color: #a5b4fc;
      margin-bottom: 4px;
      letter-spacing: 0.01em;
    }
    .ydh-translation {
      font-size: 13px;
      color: #f1f5f9;
      margin-bottom: 8px;
      line-height: 1.4;
    }
    .ydh-loading { color: #64748b; font-style: italic; }
    .ydh-error   { color: #f87171; }
    .ydh-mode-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 6px;
      padding-top: 4px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
    }
    .ydh-mode-label {
      font-size: 10px;
      color: #94a3b8;
      font-weight: 600;
    }
    .ydh-mode-pills {
      display: flex;
      gap: 3px;
    }
    .ydh-pill {
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 5px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(255, 255, 255, 0.05);
      color: #94a3b8;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.15s ease;
    }
    .ydh-pill:hover {
      color: #f1f5f9;
      background: rgba(255, 255, 255, 0.1);
    }
    .ydh-pill-active {
      background: rgba(99, 102, 241, 0.3) !important;
      border-color: rgba(99, 102, 241, 0.6) !important;
      color: #c7d2fe !important;
      font-weight: 600;
    }
    .ydh-save-btn {
      width: 100%;
      padding: 5px 10px;
      border-radius: 7px;
      border: 1px solid rgba(99,102,241,0.35);
      background: rgba(99,102,241,0.15);
      color: #a5b4fc;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s, color 0.15s;
    }
    .ydh-save-btn:hover:not(:disabled) {
      background: rgba(99,102,241,0.3);
      color: #c7d2fe;
    }
    .ydh-save-btn:disabled { opacity: 0.5; cursor: default; }

    /* ── Safe, Zero-DOM-Mutation CSS Custom Highlight API Subtitle Styling ── */
    ::highlight(ydh-vocab-mastered) {
      color: #38bdf8 !important;
      background-color: rgba(14, 165, 233, 0.28) !important;
      text-decoration: underline 2.5px solid #0ea5e9 !important;
      text-shadow: 0 0 10px rgba(56, 189, 248, 0.85), 0 1px 2px rgba(0, 0, 0, 0.9) !important;
    }

    ::highlight(ydh-vocab-easy) {
      color: #4ade80 !important;
      background-color: rgba(34, 197, 94, 0.28) !important;
      text-decoration: underline 2.5px solid #22c55e !important;
      text-shadow: 0 0 10px rgba(34, 197, 94, 0.8), 0 1px 2px rgba(0, 0, 0, 0.9) !important;
    }

    ::highlight(ydh-vocab-medium) {
      color: #facc15 !important;
      background-color: rgba(234, 179, 8, 0.28) !important;
      text-decoration: underline 2.5px solid #eab308 !important;
      text-shadow: 0 0 10px rgba(234, 179, 8, 0.8), 0 1px 2px rgba(0, 0, 0, 0.9) !important;
    }

    ::highlight(ydh-vocab-hard) {
      color: #f87171 !important;
      background-color: rgba(239, 68, 68, 0.32) !important;
      text-decoration: underline 2.5px solid #ef4444 !important;
      text-shadow: 0 0 12px rgba(239, 68, 68, 0.9), 0 1px 2px rgba(0, 0, 0, 0.9) !important;
    }

    ::highlight(ydh-vocab-unrated) {
      color: #a5b4fc !important;
      background-color: rgba(99, 102, 241, 0.25) !important;
      text-decoration: underline 2.5px solid #818cf8 !important;
      text-shadow: 0 0 10px rgba(129, 140, 248, 0.8), 0 1px 2px rgba(0, 0, 0, 0.9) !important;
    }

    /* Floating Vocab Hover Tooltip (Dark Cinema Glassmorphism) */
    #ydh-vocab-hover-tip {
      position: fixed;
      z-index: 2147483647;
      background: rgba(15, 23, 42, 0.96);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      color: #f8fafc;
      padding: 6px 14px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 600;
      white-space: nowrap;
      pointer-events: none !important;
      opacity: 0;
      visibility: hidden;
      transform: translateX(-50%) translateY(4px);
      transition: opacity 0.12s ease, transform 0.12s ease;
      border: 1px solid rgba(255, 255, 255, 0.18);
      box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.7), 0 0 12px rgba(0, 0, 0, 0.5);
      text-shadow: none !important;
    }
    #ydh-vocab-hover-tip.ydh-visible {
      opacity: 1;
      visibility: visible;
      transform: translateX(-50%) translateY(0);
    }

    /* ── Vocabulary Library Subtitle Highlighting (Cinema Quality) ── */
    .ydh-vocab-word {
      position: relative !important;
      display: inline-block !important;
      border-radius: 4px !important;
      padding: 0 4px !important;
      margin: 0 1px !important;
      cursor: pointer !important;
      font-weight: 700 !important;
      line-height: inherit !important;
      vertical-align: baseline !important;
      transition: all 0.15s ease-in-out !important;
      user-select: text !important;
      -webkit-user-select: text !important;
    }

    /* Mastered: Cinema Sky Blue glow & underline */
    .ydh-vocab-mastered {
      color: #38bdf8 !important;
      text-shadow: 0 0 12px rgba(56, 189, 248, 0.85), 0 1px 3px rgba(0, 0, 0, 0.9) !important;
      border-bottom: 2.5px solid #0ea5e9 !important;
      background: rgba(14, 165, 233, 0.18) !important;
    }

    /* Easy: Emerald Green glow & underline */
    .ydh-vocab-easy {
      color: #4ade80 !important;
      text-shadow: 0 0 12px rgba(34, 197, 94, 0.8), 0 1px 3px rgba(0, 0, 0, 0.9) !important;
      border-bottom: 2.5px solid #22c55e !important;
      background: rgba(34, 197, 94, 0.18) !important;
    }

    /* Medium: Amber Yellow glow & underline */
    .ydh-vocab-medium {
      color: #facc15 !important;
      text-shadow: 0 0 12px rgba(234, 179, 8, 0.8), 0 1px 3px rgba(0, 0, 0, 0.9) !important;
      border-bottom: 2.5px solid #eab308 !important;
      background: rgba(234, 179, 8, 0.18) !important;
    }

    /* Hard: Coral Red glow & underline */
    .ydh-vocab-hard {
      color: #f87171 !important;
      text-shadow: 0 0 14px rgba(239, 68, 68, 0.9), 0 1px 3px rgba(0, 0, 0, 0.9) !important;
      border-bottom: 2.5px solid #ef4444 !important;
      background: rgba(239, 68, 68, 0.22) !important;
    }

    /* Unrated / New: Indigo glow & underline */
    .ydh-vocab-unrated {
      color: #a5b4fc !important;
      text-shadow: 0 0 12px rgba(129, 140, 248, 0.8), 0 1px 3px rgba(0, 0, 0, 0.9) !important;
      border-bottom: 2.5px solid #818cf8 !important;
      background: rgba(99, 102, 241, 0.18) !important;
    }

    .ydh-vocab-word:hover {
      filter: brightness(1.25) !important;
      transform: scale(1.04) !important;
    }

    /* Instant CSS Floating Hover Tooltip (Dark Cinema Glassmorphism) */
    .ydh-vocab-word::after {
      content: attr(data-ydh-tip);
      position: absolute;
      bottom: calc(100% + 8px);
      left: 50%;
      transform: translateX(-50%) translateY(4px);
      background: rgba(15, 23, 42, 0.96);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      color: #f8fafc;
      padding: 6px 14px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 600;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.15s ease, transform 0.15s ease;
      z-index: 2147483647;
      border: 1px solid rgba(255, 255, 255, 0.18);
      box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.7), 0 0 12px rgba(0, 0, 0, 0.5);
      text-shadow: none !important;
    }

    .ydh-vocab-word:hover::after {
      opacity: 1;
      visibility: visible;
      transform: translateX(-50%) translateY(0);
    }

    /* Tooltip badges & saved state */
    .ydh-word-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 8px;
    }
    .ydh-diff-badge {
      display: inline-flex;
      align-items: center;
      padding: 2px 8px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.02em;
    }
    .ydh-badge-mastered {
      background: rgba(14, 165, 233, 0.2);
      color: #38bdf8;
      border: 1px solid rgba(14, 165, 233, 0.4);
    }
    .ydh-badge-easy {
      background: rgba(34, 197, 94, 0.2);
      color: #4ade80;
      border: 1px solid rgba(34, 197, 94, 0.4);
    }
    .ydh-badge-medium {
      background: rgba(234, 179, 8, 0.2);
      color: #facc15;
      border: 1px solid rgba(234, 179, 8, 0.4);
    }
    .ydh-badge-hard {
      background: rgba(239, 68, 68, 0.2);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.4);
    }
    .ydh-badge-unrated {
      background: rgba(99, 102, 241, 0.2);
      color: #a5b4fc;
      border: 1px solid rgba(99, 102, 241, 0.4);
    }

    /* Quick Rate Buttons in Video Tooltip */
    .ydh-diff-rate-btn {
      padding: 5px 3px;
      font-size: 10px;
      font-weight: 700;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #cbd5e1;
      cursor: pointer;
      transition: all 0.15s ease;
      text-align: center;
      white-space: nowrap;
    }
    .ydh-diff-rate-btn:hover {
      background: rgba(255, 255, 255, 0.12);
      transform: translateY(-1px);
    }
    .ydh-diff-rate-btn.active[data-rate="hard"] {
      background: rgba(239, 68, 68, 0.3);
      border-color: #ef4444;
      color: #fca5a5;
    }
    .ydh-diff-rate-btn.active[data-rate="medium"] {
      background: rgba(234, 179, 8, 0.3);
      border-color: #eab308;
      color: #fde047;
    }
    .ydh-diff-rate-btn.active[data-rate="easy"] {
      background: rgba(34, 197, 94, 0.3);
      border-color: #22c55e;
      color: #86efac;
    }
    .ydh-diff-rate-btn.active[data-rate="mastered"] {
      background: rgba(14, 165, 233, 0.3);
      border-color: #0ea5e9;
      color: #7dd3fc;
      box-shadow: 0 0 10px rgba(14, 165, 233, 0.4);
    }
    .ydh-saved-btn {
      background: rgba(34, 197, 94, 0.2) !important;
      border-color: rgba(34, 197, 94, 0.5) !important;
      color: #4ade80 !important;
      cursor: default !important;
    }

    /* Only actual subtitle text spans are interactive with pointer cursor */
    .atvwebplayersdk-captions-text span,
    .atvwebplayersdk-captions-text,
    [class*="captions-text"] span,
    [class*="captions-text"],
    .timedTextBackground span,
    .timedTextOutput span,
    .player-timedtext-text-container span,
    .caption-visual-line span,
    .caption-visual-line,
    .caption-window span,
    .ytp-caption-segment,
    .dss-subtitle-renderer-line {
      cursor: pointer !important;
      user-select: text !important;
      -webkit-user-select: text !important;
    }

    /* Subtitle Sentence Translation Bar (True Cinema Subtitle Style - Instant Zero-Lag Snap) */
    #ydh-sub-translation-bar {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      position: absolute;
      max-width: 90vw;
      text-align: center;
      opacity: 0;
      pointer-events: none;
      user-select: none;
      -webkit-user-select: none;
      transition: none !important;
      z-index: 2147483646;
    }
    #ydh-sub-translation-bar.ydh-sub-visible {
      opacity: 1 !important;
    }
    .ydh-sub-text {
      display: inline-block;
      background: rgba(0, 0, 0, 0.82);
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
      color: #ffeb3b; /* Cinema Subtitle Yellow */
      font-family: 'YouTube Noto', Roboto, 'Segoe UI', -apple-system, BlinkMacSystemFont, Arial, sans-serif;
      font-size: clamp(20px, 2.4vw, 30px);
      font-weight: 700;
      line-height: 1.35;
      padding: 5px 18px;
      border-radius: 6px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.7);
      text-shadow:
        0 0 3px #000,
        0 0 6px #000,
        -1.5px -1.5px 0 #000,
         1.5px -1.5px 0 #000,
        -1.5px  1.5px 0 #000,
         1.5px  1.5px 0 #000;
      letter-spacing: 0.015em;
      text-align: center;
      max-width: 86vw;
      word-wrap: break-word;
    }
    .ydh-sub-text.ydh-sub-loading {
      color: #fde047;
      opacity: 0.85;
      font-style: italic;
      font-size: clamp(16px, 1.8vw, 22px);
      padding: 3px 14px;
    }

    /* Subtitle Navigation HUD Toast (A / D / S keys) */
    #ydh-sub-nav-toast {
      position: fixed;
      top: 48px;
      left: 50%;
      transform: translateX(-50%) translateY(-10px);
      background: rgba(15, 23, 42, 0.92);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      border: 1px solid rgba(99, 102, 241, 0.5);
      color: #f8fafc;
      padding: 8px 24px;
      border-radius: 9999px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 600;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6), 0 0 15px rgba(99, 102, 241, 0.3);
      z-index: 2147483647;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s ease, transform 0.15s ease;
      max-width: 80vw;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      text-align: center;
    }
    #ydh-sub-nav-toast.ydh-nav-visible {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }

    /* Floating Subtitle Navigation Dock (Left Screen) */
    #ydh-nav-controls {
      position: fixed;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 6px;
      background: rgba(15, 23, 42, 0.78);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 30px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.55);
      z-index: 2147483645;
      opacity: 0.38;
      transition: opacity 0.22s cubic-bezier(0.16, 1, 0.3, 1), transform 0.22s cubic-bezier(0.16, 1, 0.3, 1);
      user-select: none;
      -webkit-user-select: none;
      pointer-events: auto;
    }
    #ydh-nav-controls:hover {
      opacity: 1 !important;
      transform: translateY(-50%) scale(1.06);
      box-shadow: 0 12px 36px rgba(0, 0, 0, 0.7), 0 0 16px rgba(99, 102, 241, 0.3);
    }
    .ydh-nav-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      outline: none;
      background: rgba(255, 255, 255, 0.08);
      color: #f1f5f9;
      border-radius: 50%;
      cursor: pointer;
      transition: background 0.15s ease, transform 0.12s ease, color 0.15s ease;
      padding: 0;
      margin: 0;
    }
    .ydh-nav-btn:hover {
      background: rgba(99, 102, 241, 0.9);
      color: #ffffff;
      transform: scale(1.12);
      box-shadow: 0 0 14px rgba(99, 102, 241, 0.6);
    }
    .ydh-nav-btn:active {
      transform: scale(0.92);
    }
    .ydh-nav-btn svg {
      width: 17px;
      height: 17px;
      pointer-events: none;
    }
    .ydh-nav-divider {
      width: 22px;
      height: 1px;
      background: rgba(255, 255, 255, 0.2);
      margin: 2px auto;
    }
    .ydh-nav-btn.ydh-nav-settings.ydh-active {
      background: rgba(99, 102, 241, 0.95);
      color: #ffffff;
      box-shadow: 0 0 12px rgba(99, 102, 241, 0.6);
    }
    #ydh-nav-menu {
      position: absolute;
      left: 54px;
      top: -6px;
      min-width: 230px;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 14px;
      padding: 8px;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.75), 0 0 18px rgba(99, 102, 241, 0.25);
      display: none;
      flex-direction: column;
      gap: 4px;
      z-index: 2147483647;
      user-select: none;
      -webkit-user-select: none;
    }
    #ydh-nav-menu.ydh-menu-open {
      display: flex !important;
    }
    .ydh-menu-header {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #94a3b8;
      padding: 4px 8px 6px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      margin-bottom: 4px;
    }
    .ydh-menu-item {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding: 7px 10px;
      border: 1px solid transparent;
      background: transparent;
      border-radius: 8px;
      cursor: pointer;
      text-align: left;
      transition: background 0.15s ease, border-color 0.15s ease;
      color: #e2e8f0;
      font-family: inherit;
    }
    .ydh-menu-item:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    .ydh-menu-item.ydh-item-active {
      background: rgba(99, 102, 241, 0.25);
      border-color: rgba(99, 102, 241, 0.5);
    }
    .ydh-item-title-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    .ydh-item-title {
      font-size: 13px;
      font-weight: 600;
      color: #f8fafc;
    }
    .ydh-item-check {
      width: 15px;
      height: 15px;
      opacity: 0;
      color: #818cf8;
      stroke-width: 3;
    }
    .ydh-menu-item.ydh-item-active .ydh-item-check {
      opacity: 1;
    }
    .ydh-item-desc {
      font-size: 11px;
      color: #94a3b8;
      margin-top: 2px;
      line-height: 1.25;
    }
  `;

  (document.head || document.documentElement).appendChild(style);
}

// ── Escape HTML ────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Initialize styles, navigation controls, vocabulary engine, and proactive lookup on load
injectStyles();
ensureNavControls();
setInterval(ensureNavControls, 2000);
loadUserVocabFromStorage();
setupSubtitleObserver();
setInterval(highlightVocabInActiveSubtitles, 250);
tryLoadSubtitlesFromPerformanceResources();
setTimeout(tryLoadSubtitlesFromPerformanceResources, 1500);
setTimeout(tryLoadSubtitlesFromPerformanceResources, 4000);
